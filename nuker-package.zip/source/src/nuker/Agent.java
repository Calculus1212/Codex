package nuker;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Runtime attachment for Fabric 1.21.8 intermediary namespace. No bytecode patches. */
public final class Agent {
    private static final String INSTALLED = "nuker.agent.installed";
    private static final String STOP = "nuker.agent.stop";
    public static void agentmain(String options, Instrumentation instrumentation) throws Exception {
        if ("stop".equals(options)) { System.setProperty(STOP, "true"); return; }
        Config config = Config.parse(options);
        synchronized (Agent.class) {
            if (System.getProperty(INSTALLED) != null)
                throw new IllegalStateException("Already attached. Use END to stop or attach with 'stop'. Restart Minecraft to reinstall.");
            Class<?> minecraft = Arrays.stream(instrumentation.getAllLoadedClasses())
                .filter(c -> c.getName().equals("net.minecraft.class_310")).findFirst()
                .orElseThrow(() -> new IllegalStateException("No running intermediary Minecraft client found."));
            Object client = minecraft.getMethod("method_1551").invoke(null);
            ClassLoader loader = minecraft.getClassLoader();
            Hooks hooks = new Hooks(loader, config);
            // Use client-thread tasks between ticks, including when Fabric API is present.
            // Keeping a single pending task prevents bursts after a busy frame or pause.
            Runnable install = () -> {
                ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "Nuker schedule"); t.setDaemon(true); return t;
                });
                AtomicBoolean pending = new AtomicBoolean();
                timer.scheduleWithFixedDelay(() -> {
                    if (hooks.stopped) { timer.shutdown(); return; }
                    if (pending.compareAndSet(false, true)) {
                        try {
                            ((Executor)client).execute(() -> {
                                try { hooks.tick(client); }
                                finally { pending.set(false); }
                            });
                        } catch (RuntimeException failure) {
                            pending.set(false); hooks.stopped = true; timer.shutdown();
                            System.err.println("[Nuker] Stopped after scheduling failure: " + failure);
                        }
                    }
                }, 0, config.interval, TimeUnit.MILLISECONDS);
            };
            CompletableFuture<Void> ready = new CompletableFuture<>();
            System.setProperty(INSTALLED, "installing");
            System.clearProperty(STOP);
            Runnable finalInstall = install;
            try {
                ((Executor)client).execute(() -> {
                    try {
                        if (Boolean.getBoolean(STOP)) throw new IllegalStateException("Attachment cancelled");
                        finalInstall.run();
                        System.setProperty(INSTALLED, "true");
                        System.out.println("[Nuker] Attached, OFF. N toggles; END stops. Radius=" + config.radius + ", blocks/cycle=" + config.budget + ", interval=" + config.interval + "ms");
                        ready.complete(null);
                    } catch (Throwable e) { System.clearProperty(INSTALLED); ready.completeExceptionally(e); }
                });
                ready.get(10, TimeUnit.SECONDS);
            } catch (Exception failure) {
                System.setProperty(STOP, "true");
                System.clearProperty(INSTALLED);
                throw failure;
            }
        }
    }

    record Config(double radius, int budget, int interval) {
        static Config parse(String text) {
            double radius = 6; int budget = 128; int interval = 100;
            if (text != null && !text.isBlank()) for (String option : text.split(",")) {
                String[] pair = option.trim().split("=", -1);
                if (pair.length != 2) throw new IllegalArgumentException("Expected radius=6,budget=128,interval=100 or stop");
                switch (pair[0]) {
                    case "radius" -> radius = Double.parseDouble(pair[1]);
                    case "budget" -> budget = Integer.parseInt(pair[1]);
                    case "interval" -> interval = Integer.parseInt(pair[1]);
                    default -> throw new IllegalArgumentException("Unknown option: " + pair[0]);
                }
            }
            if (!Double.isFinite(radius) || radius <= 0 || radius > 6 || budget < 1 || budget > 512 || interval < 5 || interval > 1000)
                throw new IllegalArgumentException("radius must be >0 and <=6; budget must be 1..512; interval must be 5..1000 ms");
            return new Config(radius, budget, interval);
        }
    }

    static final class Hooks {
        final Config config;
        final Field player, world, manager, screen, vx, vy, vz, cooldown;
        final Method focused, window, handle, key, eye, creative, range, state, air, hardness, attack, progress, cancel, facing;
        final Constructor<?> blockPos;
        boolean enabled, previousToggle;
        volatile boolean stopped;
        Object lastWorld;
        Target survivalTarget;
        Object survivalPos, survivalWorld, survivalManager;
        List<Target> cachedTargets;
        double cachedX, cachedY, cachedZ, cachedRadius;
        Hooks(ClassLoader loader, Config config) throws Exception {
            this.config = config;
            Class<?> mc = Class.forName("net.minecraft.class_310", false, loader);
            Class<?> entity = Class.forName("net.minecraft.class_1297", false, loader);
            Class<?> pe = Class.forName("net.minecraft.class_1657", false, loader);
            Class<?> pos = Class.forName("net.minecraft.class_2338", false, loader);
            Class<?> direction = Class.forName("net.minecraft.class_2350", false, loader);
            Class<?> view = Class.forName("net.minecraft.class_1922", false, loader);
            Class<?> bs = Class.forName("net.minecraft.class_2680", false, loader);
            Class<?> vec = Class.forName("net.minecraft.class_243", false, loader);
            player = mc.getField("field_1724"); world = mc.getField("field_1687");
            manager = mc.getField("field_1761"); screen = mc.getField("field_1755");
            focused = mc.getMethod("method_1569"); window = mc.getMethod("method_22683");
            handle = Class.forName("net.minecraft.class_1041", false, loader).getMethod("method_4490");
            key = Class.forName("org.lwjgl.glfw.GLFW", false, loader).getMethod("glfwGetKey", long.class, int.class);
            eye = entity.getMethod("method_33571"); creative = pe.getMethod("method_68878");
            range = pe.getMethod("method_55754");
            state = view.getMethod("method_8320", pos); air = bs.getMethod("method_26215");
            hardness = bs.getMethod("method_26214", view, pos);
            Class<?> interaction = Class.forName("net.minecraft.class_636", false, loader);
            attack = interaction.getMethod("method_2910", pos, direction);
            progress = interaction.getMethod("method_2902", pos, direction);
            cancel = interaction.getMethod("method_2925");
            cooldown = interaction.getDeclaredField("field_3716");
            cooldown.setAccessible(true);
            facing = direction.getMethod("method_10142", double.class, double.class, double.class);
            blockPos = pos.getConstructor(int.class, int.class, int.class);
            vx = vec.getField("field_1352"); vy = vec.getField("field_1351"); vz = vec.getField("field_1350");
        }
        void tick(Object client) {
            if (stopped) return;
            try {
                Object w = world.get(client), p = player.get(client), m = manager.get(client);
                if (Boolean.getBoolean(STOP)) { cancelMining(w, m); stopped = true; enabled = false; return; }
                boolean active = (boolean)focused.invoke(client);
                long id = (long)handle.invoke(window.invoke(client));
                if (active && (int)key.invoke(null, id, 269) == 1) {
                    cancelMining(w, m); stopped = true; enabled = false; System.out.println("[Nuker] Stopped until Minecraft restarts."); return;
                }
                boolean toggle = active && (int)key.invoke(null, id, 78) == 1;
                if (w != lastWorld) { cancelMining(w, m); enabled = false; lastWorld = w; }
                if (toggle && !previousToggle && screen.get(client) == null && p != null && w != null) {
                    enabled = !enabled; System.out.println("[Nuker] " + (enabled ? "ON" : "OFF"));
                }
                previousToggle = toggle;
                if (!enabled || !active || screen.get(client) != null || p == null || w == null || m == null) {
                    cancelMining(w, m); return;
                }
                Object eyes = eye.invoke(p);
                double x = vx.getDouble(eyes), y = vy.getDouble(eyes), z = vz.getDouble(eyes);
                double r = Math.min(config.radius, (double)range.invoke(p));
                if (!Double.isFinite(r) || r <= 0) { cancelMining(w, m); return; }
                if (cachedTargets == null || x != cachedX || y != cachedY || z != cachedZ || r != cachedRadius) {
                    cachedTargets = targets(x, y, z, r);
                    cachedX = x; cachedY = y; cachedZ = z; cachedRadius = r;
                }
                List<Target> targets = cachedTargets;
                if (!(boolean)creative.invoke(p)) {
                    mineSurvival(targets, w, m, x, y, z, r);
                    return;
                }
                cancelMining(w, m);
                int attempted = 0;
                int originalCooldown = cooldown.getInt(m);
                try {
                    for (Target t : targets) {
                        Object pos = blockPos.newInstance(t.x, t.y, t.z);
                        Object block = state.invoke(w, pos);
                        if ((boolean)air.invoke(block) || (float)hardness.invoke(block, w, pos) < 0) continue;
                        Object side = facing.invoke(null, x-(t.x+.5), y-(t.y+.5), z-(t.z+.5));
                        cooldown.setInt(m, 0);
                        attack.invoke(m, pos, side);
                        if (++attempted >= config.budget) break;
                    }
                } finally { cooldown.setInt(m, originalCooldown); }
            } catch (Throwable e) {
                stopped = true; enabled = false;
                System.err.println("[Nuker] Stopped after runtime failure: " + e);
                e.printStackTrace(System.err);
            }
        }
        void clearMining() {
            survivalTarget = null; survivalPos = null; survivalWorld = null; survivalManager = null;
        }
        void cancelMining(Object w, Object m) throws ReflectiveOperationException {
            Object owner = survivalManager;
            boolean sameSession = survivalPos != null && survivalWorld == w && owner == m;
            clearMining();
            if (sameSession) cancel.invoke(owner);
        }
        void mineSurvival(List<Target> targets, Object w, Object m, double x, double y, double z, double r)
            throws ReflectiveOperationException {
            if (survivalTarget != null) {
                Target t = survivalTarget;
                double dx = t.x+.5-x, dy = t.y+.5-y, dz = t.z+.5-z;
                if (survivalWorld != w || survivalManager != m || dx*dx+dy*dy+dz*dz > r*r) {
                    cancelMining(w, m);
                } else {
                    Object block = state.invoke(w, survivalPos);
                    if ((boolean)air.invoke(block) || (float)hardness.invoke(block, w, survivalPos) < 0)
                        cancelMining(w, m);
                }
            }
            for (int attempt = 0; attempt < config.budget; attempt++) {
                if (survivalTarget == null) {
                    for (Target t : targets) {
                        Object pos = blockPos.newInstance(t.x, t.y, t.z);
                        Object block = state.invoke(w, pos);
                        if ((boolean)air.invoke(block) || (float)hardness.invoke(block, w, pos) < 0) continue;
                        survivalTarget = t; survivalPos = pos; survivalWorld = w; survivalManager = m;
                        break;
                    }
                    if (survivalTarget == null) return;
                }
                Target t = survivalTarget;
                Object side = facing.invoke(null, x-(t.x+.5), y-(t.y+.5), z-(t.z+.5));
                boolean accepted = (boolean)attack.invoke(m, survivalPos, side);
                if (accepted && !(boolean)air.invoke(state.invoke(w, survivalPos)))
                    progress.invoke(m, survivalPos, side);
                // Keep the same target across cycles until its normal mining progress finishes.
                // Survival cooldowns and permissions remain controlled by Minecraft.
                if (!(boolean)air.invoke(state.invoke(w, survivalPos))) return;
                clearMining();
            }
        }
    }
    record Target(int x, int y, int z, double distance) {}
    static List<Target> targets(double x, double y, double z, double r) {
        List<Target> result = new ArrayList<>();
        for (int bx=(int)Math.floor(x-r); bx<=Math.floor(x+r); bx++)
            for (int by=(int)Math.floor(y-r); by<=Math.floor(y+r); by++)
                for (int bz=(int)Math.floor(z-r); bz<=Math.floor(z+r); bz++) {
                    double d = (bx+.5-x)*(bx+.5-x)+(by+.5-y)*(by+.5-y)+(bz+.5-z)*(bz+.5-z);
                    if (d <= r*r) result.add(new Target(bx, by, bz, d));
                }
        result.sort(Comparator.comparingDouble(Target::distance));
        return result;
    }
}
