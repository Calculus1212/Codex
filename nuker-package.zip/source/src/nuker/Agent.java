package nuker;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Runtime attachment for Fabric 1.21.8 intermediary namespace. No bytecode patches. */
public final class Agent {
    private static final String INSTALLED = "nuker.agent.installed";
    private static final String STOP = "nuker.agent.stop";
    public static void agentmain(String options, Instrumentation instrumentation) throws Exception {
        if ("stop".equals(options)) { System.setProperty(STOP, "true"); return; }
        Config config = Config.parse(options);
        synchronized (Agent.class) {
            if (System.getProperty(INSTALLED) != null)
                throw new IllegalStateException("Already attached. Use END to stop or attach with 'stop'. Restart Minecraft to reinstall.");
            Class<?> minecraft = Arrays.stream(instrumentation.getAllLoadedClasses())
                .filter(c -> c.getName().equals("net.minecraft.class_310")).findFirst()
                .orElseThrow(() -> new IllegalStateException("No running intermediary Minecraft client found."));
            Object client = minecraft.getMethod("method_1551").invoke(null);
            ClassLoader loader = minecraft.getClassLoader();
            Hooks hooks = new Hooks(loader, config);
            // Use client-thread tasks between ticks, including when Fabric API is present.
            // Keeping a single pending task prevents bursts after a busy frame or pause.
            Runnable install = () -> {
                ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "Nuker schedule"); t.setDaemon(true); return t;
                });
                class Dispatch implements Runnable {
                    @Override public void run() {
                        if (hooks.stopped) { timer.shutdown(); return; }
                        try {
                            ((Executor)client).execute(() -> {
                                try { hooks.tick(client); }
                                finally {
                                    if (hooks.stopped) timer.shutdown();
                                    else timer.schedule(this, config.interval, TimeUnit.MILLISECONDS);
                                }
                            });
                        } catch (RuntimeException failure) {
                            hooks.stopped = true; timer.shutdown();
                            System.err.println("[Nuker] Stopped after scheduling failure: " + failure);
                        }
                    }
                }
                timer.schedule(new Dispatch(), 0, TimeUnit.MILLISECONDS);
            };
            CompletableFuture<Void> ready = new CompletableFuture<>();
            System.setProperty(INSTALLED, "installing");
            System.clearProperty(STOP);
            Runnable finalInstall = install;
            try {
                ((Executor)client).execute(() -> {
                    try {
                        if (Boolean.getBoolean(STOP)) throw new IllegalStateException("Attachment cancelled");
                        finalInstall.run();
                        System.setProperty(INSTALLED, "true");
                        System.out.println("[Nuker] Attached, OFF. N toggles; END stops. Radius=" + config.radius + ", attempts/cycle=" + (config.budget == 0 ? "all" : config.budget) + ", interval=" + config.interval + "ms");
                        ready.complete(null);
                    } catch (Throwable e) { System.clearProperty(INSTALLED); ready.completeExceptionally(e); }
                });
                ready.get(10, TimeUnit.SECONDS);
            } catch (Exception failure) {
                System.setProperty(STOP, "true");
                System.clearProperty(INSTALLED);
                throw failure;
            }
        }
    }

    record Config(double radius, int budget, int interval) {
        static Config parse(String text) {
            double radius = 15; int budget = 0; int interval = 1000;
            if (text != null && !text.isBlank()) for (String option : text.split(",")) {
                String[] pair = option.trim().split("=", -1);
                if (pair.length != 2) throw new IllegalArgumentException("Expected radius=15,budget=0,interval=1000 or stop");
                switch (pair[0]) {
                    case "radius" -> radius = Double.parseDouble(pair[1]);
                    case "budget" -> budget = Integer.parseInt(pair[1]);
                    case "interval" -> interval = Integer.parseInt(pair[1]);
                    default -> throw new IllegalArgumentException("Unknown option: " + pair[0]);
                }
            }
            if (!Double.isFinite(radius) || radius <= 0 || radius > 15 || budget < 0 || budget > 512 || interval < 5 || interval > 1000)
                throw new IllegalArgumentException("radius must be >0 and <=15; budget must be 0..512 (0 means all blocks); interval must be 5..1000 ms");
            return new Config(radius, budget, interval);
        }
    }

    static final class Hooks {
        final Config config;
        final Field player, world, manager, screen, vx, vy, vz;
        final Method focused, window, handle, key, eye, state, getBlock, facing, sendSequenced, syncSelected;
        final Constructor<?> blockPos, packet;
        final Class<?> creator, redstoneType;
        final ClassLoader loader;
        final Object startAction;
        boolean enabled, previousToggle;
        volatile boolean stopped;
        Object lastWorld;
        List<Target> cachedTargets;
        double cachedX, cachedY, cachedZ, cachedRadius;
        Hooks(ClassLoader loader, Config config) throws Exception {
            this.config = config; this.loader = loader;
            Class<?> mc = Class.forName("net.minecraft.class_310", false, loader);
            Class<?> entity = Class.forName("net.minecraft.class_1297", false, loader);
            Class<?> pos = Class.forName("net.minecraft.class_2338", false, loader);
            Class<?> direction = Class.forName("net.minecraft.class_2350", false, loader);
            Class<?> view = Class.forName("net.minecraft.class_1922", false, loader);
            Class<?> bs = Class.forName("net.minecraft.class_2680", false, loader);
            Class<?> vec = Class.forName("net.minecraft.class_243", false, loader);
            player = mc.getField("field_1724"); world = mc.getField("field_1687");
            manager = mc.getField("field_1761"); screen = mc.getField("field_1755");
            focused = mc.getMethod("method_1569"); window = mc.getMethod("method_22683");
            handle = Class.forName("net.minecraft.class_1041", false, loader).getMethod("method_4490");
            key = Class.forName("org.lwjgl.glfw.GLFW", false, loader).getMethod("glfwGetKey", long.class, int.class);
            eye = entity.getMethod("method_33571");
            state = view.getMethod("method_8320", pos); getBlock = bs.getMethod("method_26204");
            redstoneType = Class.forName("net.minecraft.class_2449", false, loader);
            Class<?> interaction = Class.forName("net.minecraft.class_636", false, loader);
            creator = Class.forName("net.minecraft.class_7204", false, loader);
            sendSequenced = interaction.getDeclaredMethod("method_41931", Class.forName("net.minecraft.class_638", false, loader), creator);
            sendSequenced.setAccessible(true);
            syncSelected = interaction.getDeclaredMethod("method_2911"); syncSelected.setAccessible(true);
            Class<?> action = Class.forName("net.minecraft.class_2846$class_2847", false, loader);
            startAction = action(action, "START_DESTROY_BLOCK");
            packet = Class.forName("net.minecraft.class_2846", false, loader).getConstructor(action, pos, direction, int.class);
            facing = direction.getMethod("method_10142", double.class, double.class, double.class);
            blockPos = pos.getConstructor(int.class, int.class, int.class);
            vx = vec.getField("field_1352"); vy = vec.getField("field_1351"); vz = vec.getField("field_1350");
        }
        static Object action(Class<?> actionType, String name) {
            return Arrays.stream(actionType.getEnumConstants()).filter(value -> ((Enum<?>)value).name().equals(name))
                .findFirst().orElseThrow(() -> new IllegalStateException("Missing block action: " + name));
        }
        void send(Object m, Object w, Object action, Object pos, Object side) throws ReflectiveOperationException {
            Object factory = Proxy.newProxyInstance(loader, new Class<?>[]{creator}, (proxy, method, args) -> {
                if (method.getName().equals("predict")) return packet.newInstance(action, pos, side, (int)args[0]);
                if (method.getName().equals("toString")) return "Nuker block packet creator";
                if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                if (method.getName().equals("equals")) return proxy == args[0];
                throw new UnsupportedOperationException(method.toString());
            });
            sendSequenced.invoke(m, w, factory);
        }
        void tick(Object client) {
            if (stopped) return;
            try {
                Object w = world.get(client), p = player.get(client), m = manager.get(client);
                if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                boolean active = (boolean)focused.invoke(client);
                long id = (long)handle.invoke(window.invoke(client));
                if (active && (int)key.invoke(null, id, 269) == 1) {
                    stopped = true; enabled = false; System.out.println("[Nuker] Stopped until Minecraft restarts."); return;
                }
                boolean toggle = active && (int)key.invoke(null, id, 78) == 1;
                if (w != lastWorld) { enabled = false; lastWorld = w; }
                if (toggle && !previousToggle && screen.get(client) == null && p != null && w != null) {
                    enabled = !enabled; System.out.println("[Nuker] " + (enabled ? "ON" : "OFF"));
                }
                previousToggle = toggle;
                if (!enabled || !active || screen.get(client) != null || p == null || w == null || m == null) return;
                Object eyes = eye.invoke(p);
                double x = vx.getDouble(eyes), y = vy.getDouble(eyes), z = vz.getDouble(eyes);
                double r = config.radius;
                if (cachedTargets == null || x != cachedX || y != cachedY || z != cachedZ || r != cachedRadius) {
                    cachedTargets = targets(x, y, z, r);
                    cachedX = x; cachedY = y; cachedZ = z; cachedRadius = r;
                }
                syncSelected.invoke(m);
                int attempted = 0;
                for (Target t : cachedTargets) {
                    if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                    Object pos = blockPos.newInstance(t.x, t.y, t.z);
                    if (!redstoneType.isInstance(getBlock.invoke(state.invoke(w, pos)))) continue;
                    Object side = facing.invoke(null, x-(t.x+.5), y-(t.y+.5), z-(t.z+.5));
                    send(m, w, startAction, pos, side);
                    // No mining progress or block-removal check: move straight to the next position.
                    if (config.budget > 0 && ++attempted >= config.budget) break;
                }
            } catch (Throwable e) {
                stopped = true; enabled = false;
                System.err.println("[Nuker] Stopped after runtime failure: " + e);
                e.printStackTrace(System.err);
            }
        }
    }
    record Target(int x, int y, int z, double distance) {}
    static List<Target> targets(double x, double y, double z, double r) {
        List<Target> result = new ArrayList<>();
        for (int bx=(int)Math.floor(x-r); bx<=Math.floor(x+r); bx++)
            for (int by=(int)Math.floor(y-r); by<=Math.floor(y+r); by++)
                for (int bz=(int)Math.floor(z-r); bz<=Math.floor(z+r); bz++) {
                    double d = (bx+.5-x)*(bx+.5-x)+(by+.5-y)*(by+.5-y)+(bz+.5-z)*(bz+.5-z);
                    if (d <= r*r) result.add(new Target(bx, by, bz, d));
                }
        result.sort(Comparator.comparingDouble(Target::distance));
        return result;
    }
}
