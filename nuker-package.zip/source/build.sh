#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build/classes dist
java com.sun.tools.javac.Main -source 21 -target 21 --add-modules jdk.attach -d build/classes src/nuker/*.java
cat > build/MANIFEST.MF <<'MANIFEST'
Manifest-Version: 1.0
Main-Class: nuker.Attach
Agent-Class: nuker.Agent
Can-Redefine-Classes: false
Can-Retransform-Classes: false

MANIFEST
java sun.tools.jar.Main --create --file dist/nuker-agent.jar --manifest build/MANIFEST.MF -C build/classes .
