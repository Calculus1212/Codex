import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import java.util.*;
public final class PacketFixture {
 static final class_310 mc=class_310.INSTANCE; static int checks;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static void cycle() throws Exception {
  long until=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>until)throw new AssertionError("No scheduled client work");Thread.sleep(1);}
 }
 static List<class_2846> drain(){List<class_2846> sent=new ArrayList<>(mc.field_1761.packets);mc.field_1761.packets.clear();return sent;}
 static void stop() throws Exception {
  System.setProperty("nuker.agent.stop","true");cycle();check(drain().isEmpty(),"stop sends no new packets");
  Thread.sleep(150);check(mc.queue.isEmpty(),"scheduler stops");
 }
 public static void main(String[] args) throws Exception {
  boolean limited=args.length>0;
  mc.field_1724.creative=false;mc.field_1724.reach=2;
  Set<class_2338> blocks=new HashSet<>();
  for(int x=-5;x<=5;x++)for(int y=-4;y<=6;y++)for(int z=-5;z<=5;z++){
   class_2338 p=new class_2338(x,y,z);if(x*x+(y-1)*(y-1)+z*z<=36){blocks.add(p);mc.field_1687.blocks.put(p,new CustomBlock());}}
  class_2338 bedrock=new class_2338(0,1,0);mc.field_1687.blocks.put(bedrock,new class_2680(false,-1));
  mc.field_1687.blocks.put(new class_2338(0,1,1),new class_2680(true,0));blocks.remove(new class_2338(0,1,1));
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  while(!"true".equals(System.getProperty("nuker.agent.installed")))cycle();
  cycle();check(drain().isEmpty(),"starts disabled");
  GLFW.n=true;cycle();long firstCycleEnded=System.nanoTime();List<class_2846> sent=drain();
  int expected=limited?2:blocks.size();check(sent.size()==expected,"one START packet per non-air block");
  Set<class_2338> attempted=new HashSet<>();int last=0;
  for(class_2846 start:sent){
   check(start.action==class_2846.class_2847.START_DESTROY_BLOCK,"only START actions are sent, never STOP or ABORT");
   check(start.sequence>last,"sequences strictly increase");last=start.sequence;
   check(attempted.add(start.pos),"each block attempted once per cycle");}
  check(mc.field_1687.blocks.containsKey(bedrock),"unconfirmed requests do not force local block removal");
  check(mc.field_1761.normalProgressCalls==0,"does not advance or wait for normal mining progress");
  check(mc.field_1761.synced>0,"syncs selected tool slot");
  if(!limited){check(attempted.equals(blocks),"all targets covered without a batch cap");
   check(attempted.stream().anyMatch(p->p.x()*p.x()+(p.y()-1)*(p.y()-1)+p.z()*p.z()>4),"client reach does not filter attempts");}
  cycle();check(System.nanoTime()-firstCycleEnded>=900_000_000L,"1000ms interval retained");
  check(drain().size()==expected,"retries surrounding blocks even while none have broken");GLFW.n=false;
  mc.field_1755=new Object();cycle();check(drain().isEmpty(),"menu pauses attempts");mc.field_1755=null;
  mc.focused=false;cycle();check(drain().isEmpty(),"lost focus pauses attempts");mc.focused=true;
  mc.field_1724.creative=true;cycle();check(drain().size()==expected,"mode change keeps request bursts enabled");
  Thread.sleep(1120);check(mc.queue.size()==1,"one pending task during busy frame");cycle();drain();
  mc.field_1687=new class_638();mc.field_1687.blocks.put(bedrock,new CustomBlock());cycle();check(drain().isEmpty(),"world change disables attempts");
  GLFW.n=true;cycle();check(drain().size()==1,"toggle enables new world");GLFW.n=false;
  stop();System.out.println("PASS "+checks+" no-wait request checks"+(limited?" (limited)":" (all blocks)"));
 }
}
