import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import java.util.*;
public final class PacketFixture {
 static final class_310 mc=class_310.INSTANCE; static int checks;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static void cycle() throws Exception {
  long until=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>until)throw new AssertionError("No scheduled client work");Thread.sleep(1);}
 }
 static List<class_2846> drain(){List<class_2846> sent=new ArrayList<>(mc.field_1761.packets);mc.field_1761.packets.clear();return sent;}
 static void stop() throws Exception {
  System.setProperty("nuker.agent.stop","true");cycle();check(drain().isEmpty(),"stop sends no new packets");
  Thread.sleep(150);check(mc.queue.isEmpty(),"scheduler stops");
 }
 public static void main(String[] args) throws Exception {
  boolean limited=args.length>0;
  mc.field_1724.creative=false;mc.field_1724.reach=2;
  Set<class_2338> blocks=new HashSet<>();
  for(int x=-15;x<=15;x++)for(int y=-14;y<=16;y++)for(int z=-15;z<=15;z++)
   mc.field_1687.blocks.put(new class_2338(x,y,z),new CustomBlock());
  class_2449 normal=new class_2449("redstone_ore"),deep=new class_2449("deepslate_redstone_ore");
  class_2338 near=new class_2338(1,1,0),nearLit=new class_2338(2,1,0),far=new class_2338(10,1,0),deepLit=new class_2338(0,11,0),boundary=new class_2338(15,1,0),negative=new class_2338(-14,1,2);
  class_2338[] orePositions={near,nearLit,far,deepLit,boundary,negative};
  for(int i=0;i<orePositions.length;i++){
   class_2338 pos=orePositions[i];blocks.add(pos);
   mc.field_1687.blocks.put(pos,new class_2680(false,3,i<2?normal:deep,i%2==1));
  }
  class_2338 outside=new class_2338(16,1,0),diagonalOutside=new class_2338(15,2,0);
  mc.field_1687.blocks.put(outside,new class_2680(false,3,normal,false));
  mc.field_1687.blocks.put(diagonalOutside,new class_2680(false,3,deep,true));
  mc.field_1687.blocks.put(new class_2338(3,1,0),new class_2680(false,3,new class_2248("diamond_ore"),false));
  mc.field_1687.blocks.put(new class_2338(0,1,1),new class_2680(true,0));
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  while(!"true".equals(System.getProperty("nuker.agent.installed")))cycle();
  cycle();check(drain().isEmpty(),"starts disabled");
  GLFW.n=true;cycle();long firstCycleEnded=System.nanoTime();List<class_2846> sent=drain();
  int expected=limited?2:blocks.size();check(sent.size()==2*expected,"one START/ABORT pair per eligible redstone ore");
  Set<class_2338> attempted=new HashSet<>();int last=0;
  for(int i=0;i<sent.size();i+=2){
   class_2846 start=sent.get(i),abort=sent.get(i+1);
   check(start.action==class_2846.class_2847.START_DESTROY_BLOCK && abort.action==class_2846.class_2847.ABORT_DESTROY_BLOCK,"START immediately followed by ABORT, never STOP");
   check(start.pos.equals(abort.pos)&&start.side==abort.side,"ABORT addresses the same block and face as START");
   check(start.sequence>last&&abort.sequence==start.sequence+1,"each packet has the next sequence with no intervening packet");last=abort.sequence;
   check(attempted.add(start.pos),"each block attempted once per cycle");}
  check(mc.field_1687.blocks.containsKey(near),"requests do not force local block removal");
  check(mc.field_1761.normalProgressCalls==0,"does not advance or wait for normal mining progress");
  check(mc.field_1761.synced>0,"syncs selected tool slot");
  if(!limited){check(attempted.equals(blocks),"only normal/deepslate redstone ores in radius are targeted, including lit states");
   check(attempted.contains(boundary),"ore exactly fifteen blocks away included");
   check(attempted.contains(negative),"negative-coordinate ore included");
   check(!attempted.contains(outside)&&!attempted.contains(diagonalOutside),"ore beyond radius excluded");
   check(attempted.stream().anyMatch(p->p.x()*p.x()+(p.y()-1)*(p.y()-1)+p.z()*p.z()>4),"client reach does not filter attempts");}
  cycle();check(System.nanoTime()-firstCycleEnded>=900_000_000L,"1000ms interval retained");
  check(drain().size()==2*expected,"retries surrounding blocks even while none have broken");GLFW.n=false;
  mc.field_1687.blocks.put(near,new CustomBlock());cycle();List<class_2846> changed=drain();
  check(changed.stream().noneMatch(packet->packet.pos.equals(near)),"block-type changes are checked on each batch");
  check(changed.size()==2*(limited?2:expected-1),"only remaining ores are requested after replacement");
  mc.field_1687.blocks.put(near,new class_2680(false,3,normal,true));cycle();
  check(drain().size()==2*expected,"new lit redstone ore is detected without rebuilding geometric cache");
  mc.field_1755=new Object();cycle();check(drain().isEmpty(),"menu pauses attempts");mc.field_1755=null;
  mc.focused=false;cycle();check(drain().isEmpty(),"lost focus pauses attempts");mc.focused=true;
  mc.field_1724.creative=true;cycle();check(drain().size()==2*expected,"mode change keeps request bursts enabled");
  Thread.sleep(1120);check(mc.queue.size()==1,"one pending task during busy frame");cycle();drain();
  mc.field_1687=new class_638();mc.field_1687.blocks.put(near,new class_2680(false,3,normal,false));cycle();check(drain().isEmpty(),"world change disables attempts");
  GLFW.n=true;cycle();check(drain().size()==2,"toggle enables new world");GLFW.n=false;
  stop();System.out.println("PASS "+checks+" redstone-only START/ABORT request checks"+(limited?" (limited)":" (all blocks)"));
 }
}
