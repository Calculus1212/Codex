import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
public class Fixture {
 static int checks;
 static void check(boolean b,String label){if(!b)throw new AssertionError(label);checks++;}
 static class_310 mc=class_310.INSTANCE;
 static void tick(){ClientTickEvents.END_CLIENT_TICK.callback.onEndTick(mc);}
 static void toggle(){GLFW.n=false;tick();GLFW.n=true;tick();GLFW.n=false;tick();}
 static void fill(){mc.field_1687.blocks.clear();for(int x=-4;x<=4;x++)for(int y=-3;y<=5;y++)for(int z=-4;z<=4;z++)mc.field_1687.blocks.put(new class_2338(x,y,z),new CustomBlock()); mc.field_1687.blocks.put(new class_2338(0,1,0),new class_2680(false,-1));}
 static void empty(){mc.field_1761.attacks.clear();}
 public static void main(String[] args)throws Exception {
  fill(); System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  long deadline=System.nanoTime()+20_000_000_000L;
  while(ClientTickEvents.END_CLIENT_TICK.callback==null){Runnable r=mc.queue.poll();if(r!=null)r.run();if(System.nanoTime()>deadline)throw new AssertionError("agent never registered");Thread.sleep(10);}
  tick();check(mc.field_1761.attacks.isEmpty(),"starts disabled");
  GLFW.n=true;tick();check(mc.field_1761.attacks.size()==2,"tick budget");
  for(class_2338 p:mc.field_1761.attacks){double d=p.x()*p.x()+(p.y()-1)*(p.y()-1)+p.z()*p.z();check(d<=4,"player reach respected");check(!p.equals(new class_2338(0,1,0)),"unbreakable skipped");check(mc.field_1687.blocks.get(p) instanceof CustomBlock,"custom block supported");}
  empty();tick();check(mc.field_1761.attacks.size()==2,"held key does not retoggle");
  empty();mc.field_1755=new Object();tick();check(mc.field_1761.attacks.isEmpty(),"screen pauses");mc.field_1755=null;
  mc.focused=false;tick();check(mc.field_1761.attacks.isEmpty(),"unfocused pauses");mc.focused=true;GLFW.n=false;tick();empty();
  mc.field_1724.creative=false;tick();check(mc.field_1761.attacks.isEmpty(),"survival does not break");mc.field_1724.creative=true;tick();check(mc.field_1761.attacks.isEmpty(),"survival disables until toggle");
  toggle();empty();mc.field_1687=new class_638();fill();tick();check(mc.field_1761.attacks.isEmpty(),"world change disables");
  toggle();empty();GLFW.end=true;tick();GLFW.end=false;toggle();check(mc.field_1761.attacks.isEmpty(),"END permanently stops");
  System.out.println("PASS "+checks+" runtime checks");
 }
}
