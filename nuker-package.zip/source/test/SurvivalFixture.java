import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
public final class SurvivalFixture {
 static final class_310 mc=class_310.INSTANCE;
 static int checks;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static void cycle() throws Exception {
  long deadline=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>deadline)throw new AssertionError("Missing scheduled work");Thread.sleep(1);}
 }
 public static void main(String[] args) throws Exception {
  mc.field_1724.creative=false;
  class_2338 first=new class_2338(1,1,0),second=new class_2338(2,1,0),outside=new class_2338(3,1,0);
  mc.field_1687.blocks.put(first,new CustomBlock());mc.field_1687.blocks.put(second,new CustomBlock());
  mc.field_1687.blocks.put(outside,new CustomBlock());
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  long deadline=System.nanoTime()+20_000_000_000L;
  while(!"true".equals(System.getProperty("nuker.agent.installed"))){cycle();if(System.nanoTime()>deadline)throw new AssertionError("Agent installation timeout");}
  cycle();check(mc.field_1761.attacks.isEmpty(),"disabled startup in survival");
  GLFW.n=true;cycle();check(mc.field_1761.progressCalls==1,"survival accepts toggle and starts progress");
  check(mc.field_1761.attacks.isEmpty(),"hard block requires gradual progress");
  long start=System.nanoTime();cycle();
  check(System.nanoTime()-start>=70_000_000L,"default interval is 100ms rather than 10ms");
  check(mc.field_1761.attacks.isEmpty(),"held toggle keeps mining without resetting progress");
  check(mc.field_1761.starts.size()==1,"same target retained across survival cycles");
  GLFW.n=false;cycle();check(mc.field_1761.attacks.equals(java.util.List.of(first)),"survival mining completes nearest block");
  check(mc.field_1761.cooldown()>0,"survival completion keeps normal cooldown");
  int calls=mc.field_1761.progressCalls,cancelled=mc.field_1761.cancellations;
  mc.field_1755=new Object();cycle();
  check(mc.field_1761.progressCalls==calls,"menu pauses progress");
  check(mc.field_1761.cancellations==cancelled+1,"menu cancels current mining action");
  mc.field_1755=null;
  for(int i=0;i<5&&mc.field_1687.blocks.containsKey(second);i++)cycle();
  check(!mc.field_1687.blocks.containsKey(second),"mining resumes and completes after menu closes");
  check(mc.field_1687.blocks.containsKey(outside),"survival respects player reach");
  class_2338 third=new class_2338(0,1,1);mc.field_1687.blocks.put(third,new CustomBlock());cycle();
  cancelled=mc.field_1761.cancellations;
  System.setProperty("nuker.agent.stop","true");cycle();
  check(mc.field_1761.cancellations==cancelled+1,"stop cancels active survival mining");
  check(mc.field_1687.blocks.containsKey(third),"stop does not finish partial block");
  Thread.sleep(150);check(mc.queue.isEmpty(),"stop shuts down scheduler");
  System.out.println("PASS "+checks+" survival and 100ms interval checks");
 }
}
