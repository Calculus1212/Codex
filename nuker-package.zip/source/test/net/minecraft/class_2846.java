package net.minecraft;
public final class class_2846 implements class_2596 {
 public enum class_2847 {START_DESTROY_BLOCK,STOP_DESTROY_BLOCK,ABORT_DESTROY_BLOCK}
 public final class_2847 action; public final class_2338 pos; public final class_2350 side; public final int sequence;
 public class_2846(class_2847 action,class_2338 pos,class_2350 side,int sequence){this.action=action;this.pos=pos;this.side=side;this.sequence=sequence;}
}
