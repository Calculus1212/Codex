package net.minecraft;
import java.util.*;
public class class_636 {
 public final List<class_2338> attacks=new ArrayList<>();
 public final List<class_2680> brokenStates=new ArrayList<>();
 private int field_3716;
 public int cooldown(){return field_3716;}
 public boolean method_2910(class_2338 p,class_2350 d) {
  if(field_3716>0) return false;
  attacks.add(p); brokenStates.add(class_310.INSTANCE.field_1687.blocks.remove(p)); field_3716=5; return true;
 }
}
