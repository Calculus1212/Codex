package net.minecraft;
import java.util.*;
public class class_636 {
 public final List<class_2338> attacks=new ArrayList<>();
 public final List<class_2680> brokenStates=new ArrayList<>();
 public final List<class_2338> starts=new ArrayList<>();
 private int field_3716;
 private class_2338 mining;
 private int work;
 public int progressCalls, cancellations;
 public int cooldown(){return field_3716;}
 public boolean method_2910(class_2338 p,class_2350 d) {
  if(class_310.INSTANCE.field_1724.creative) {
   if(field_3716>0)return false;
   remove(p);field_3716=5;return true;
  }
  if(!p.equals(mining)){mining=p;work=0;starts.add(p);}
  return true;
 }
 public boolean method_2902(class_2338 p,class_2350 d) {
  progressCalls++;
  if(field_3716>0){field_3716--;return true;}
  if(!p.equals(mining))method_2910(p,d);
  if(++work>=3){remove(p);mining=null;work=0;field_3716=2;}
  return true;
 }
 public void method_2925(){if(mining!=null)cancellations++;mining=null;work=0;}
 private void remove(class_2338 p){attacks.add(p);brokenStates.add(class_310.INSTANCE.field_1687.blocks.remove(p));}
}
