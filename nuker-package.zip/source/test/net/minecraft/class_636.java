package net.minecraft;
import java.util.*;
public class class_636 {
 public final List<class_2846> packets=new ArrayList<>();
 public int synced, normalProgressCalls;
 private int sequence;
 private void method_2911(){synced++;}
 private void method_41931(class_638 world,class_7204 creator){packets.add((class_2846)creator.predict(++sequence));}
 // Deliberately no block removal: simulate requests rejected or pending on the server.
 public boolean method_2902(class_2338 p,class_2350 side){normalProgressCalls++;return false;}
}
