package net.minecraft;
public class class_2449 extends class_2248 { public class_2449(String name){super(name);} }
