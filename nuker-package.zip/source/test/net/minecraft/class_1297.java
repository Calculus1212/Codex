package net.minecraft; public class class_1297 { public class_243 method_33571(){ return new class_243(); } }
