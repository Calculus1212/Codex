package net.minecraft; public class class_243 { public double field_1352=.5, field_1351=1.5, field_1350=.5; }
