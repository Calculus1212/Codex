package net.minecraft; public class CustomBlock extends class_2680 { public CustomBlock(){super(false,2);} }
