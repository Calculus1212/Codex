package net.fabricmc.fabric.api.event; public class Event<T> { public volatile T callback; public void register(T listener){callback=listener;} }
