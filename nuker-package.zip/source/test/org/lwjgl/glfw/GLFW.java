package org.lwjgl.glfw; public class GLFW { public static boolean n,end; public static int glfwGetKey(long w,int k){return ((k==78&&n)||(k==269&&end))?1:0;} }
