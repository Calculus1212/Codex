import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
public final class FallbackFixture {
 public static void main(String[] args) throws Exception {
  class_310 mc=class_310.INSTANCE;
  for(int x=-2;x<=2;x++)for(int y=0;y<=2;y++)for(int z=-2;z<=2;z++)mc.field_1687.blocks.put(new class_2338(x,y,z),new CustomBlock());
  System.out.println("READY "+ProcessHandle.current().pid()); System.out.flush();
  long deadline=System.nanoTime()+20_000_000_000L;
  boolean toggled=false; long enabledAt=0; boolean requested=false; int stoppedCount=0;
  while(System.nanoTime()<deadline) {
   Runnable r=mc.queue.poll(); if(r!=null)r.run();
   if("true".equals(System.getProperty("nuker.agent.installed"))&&!toggled) {
    if(!mc.field_1761.attacks.isEmpty())throw new AssertionError("starts enabled");
    GLFW.n=true; toggled=true; enabledAt=System.nanoTime();
   }
   if(toggled&&System.nanoTime()-enabledAt>200_000_000L)GLFW.n=false;
   if(!requested&&mc.field_1761.attacks.size()>=4) {
    System.out.println("MINED "+mc.field_1761.attacks.size());System.out.flush(); requested=true;
   }
   if(Boolean.getBoolean("nuker.agent.stop")) {
    stoppedCount=mc.field_1761.attacks.size();
    long end=System.nanoTime()+200_000_000L;
    while(System.nanoTime()<end){r=mc.queue.poll();if(r!=null)r.run();Thread.sleep(5);}
    if(stoppedCount!=mc.field_1761.attacks.size())throw new AssertionError("mining continued after stop");
    System.out.println("PASS fallback attachment, creative cooldown, and external stop");return;
   }
   Thread.sleep(5);
  }
  throw new AssertionError("fallback timeout");
 }
}
