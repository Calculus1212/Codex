import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
public final class FastFixture {
 static final class_310 mc=class_310.INSTANCE;
 static int checks;
 static void check(boolean condition,String label){if(!condition)throw new AssertionError(label);checks++;}
 static void cycle() throws Exception {
  long deadline=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>deadline)throw new AssertionError("Missing client-thread work");Thread.sleep(1);}
 }
 public static void main(String[] args) throws Exception {
  mc.field_1724.reach=5;
  for(int x=-6;x<=6;x++)for(int y=-5;y<=7;y++)for(int z=-6;z<=6;z++)mc.field_1687.blocks.put(new class_2338(x,y,z),new CustomBlock());
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  long deadline=System.nanoTime()+20_000_000_000L;
  while(!"true".equals(System.getProperty("nuker.agent.installed"))) {
   cycle();if(System.nanoTime()>deadline)throw new AssertionError("No agent installation");
  }
  cycle();check(mc.field_1761.attacks.isEmpty(),"disabled startup");
  GLFW.n=true;cycle();GLFW.n=false;
  check(mc.field_1761.attacks.size()==128,"128 breaks in a single cycle");
  check(mc.field_1761.cooldown()==0,"creative cooldown restored");
  boolean beyondOldRadius=false;
  for(class_2338 p:mc.field_1761.attacks) {
   double d=p.x()*p.x()+(p.y()-1)*(p.y()-1)+p.z()*p.z();
   if(d>9)beyondOldRadius=true;
   check(d<=25,"larger radius still respects player reach");
  }
  check(beyondOldRadius,"breaks blocks beyond the old three-block radius");
  int count=mc.field_1761.attacks.size();cycle();
  check(mc.field_1761.attacks.size()==count+128,"next cycle clears another 128 blocks");
  check(new java.util.HashSet<>(mc.field_1761.attacks).size()==mc.field_1761.attacks.size(),"does not reattack removed blocks");
  // A blocked main thread should leave just one pending task, rather than accumulate a burst.
  Thread.sleep(220);check(mc.queue.size()==1,"only one task pending during a busy frame");
  System.setProperty("nuker.agent.stop","true");count=mc.field_1761.attacks.size();
  Runnable r=mc.queue.poll();if(r!=null)r.run();Thread.sleep(130);
  check(mc.field_1761.attacks.size()==count,"queued task honors stop");
  check(mc.queue.isEmpty(),"timer stops scheduling after stop");
  System.out.println("PASS "+checks+" faster/larger-radius checks");
 }
}
