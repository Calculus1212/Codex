#!/usr/bin/env python3
"""Exercise actual dynamic JVM attachment against mock Minecraft classes."""
import pathlib, subprocess, shutil
root=pathlib.Path(__file__).resolve().parent
jar=root/'dist/nuker-agent.jar'
def run_fixture(cp, fixture, options):
 p=subprocess.Popen(['java','-cp',str(cp),fixture],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  line=p.stdout.readline().strip(); print(line)
  if not line.startswith('READY '): raise RuntimeError('fixture did not start')
  command=['java','--add-modules','jdk.attach','-jar',str(jar),line.split()[1],str(jar)]
  if options: command.append(options)
  subprocess.run(command,check=True,timeout=15)
  out,_=p.communicate(timeout=30);print(out,end='')
  if p.returncode!=0 or 'PASS ' not in out: raise RuntimeError(f'{fixture} failed')
 finally:
  if p.poll() is None:p.kill();p.wait()
cp=root/'build/test-classes'
run_fixture(cp,'Fixture','radius=3,budget=2')
run_fixture(cp,'FastFixture',None)
fallback=root/'build/without-fabric-api'
if fallback.exists():shutil.rmtree(fallback)
shutil.copytree(cp,fallback)
shutil.rmtree(fallback/'net/fabricmc')
run_fixture(fallback,'FastFixture',None)
run_fixture(cp,'SurvivalFixture',None)
run_fixture(fallback,'SurvivalFixture',None)
