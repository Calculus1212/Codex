#!/usr/bin/env python3
"""Exercise real dynamic JVM attachment against mock Minecraft/Fabric APIs."""
import pathlib, subprocess
root=pathlib.Path(__file__).resolve().parent
p=subprocess.Popen(['java','-cp',str(root/'build/test-classes'),'Fixture'],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
try:
    line=p.stdout.readline().strip()
    print(line)
    if not line.startswith('READY '): raise RuntimeError('fixture did not start')
    subprocess.run(['java','--add-modules','jdk.attach','-jar',str(root/'dist/nuker-agent.jar'),line.split()[1],str(root/'dist/nuker-agent.jar'),'radius=3,budget=2'],check=True)
    out,_=p.communicate(timeout=30)
    print(out,end='')
    if p.returncode != 0 or 'PASS ' not in out: raise RuntimeError('runtime fixture failed')
finally:
    if p.poll() is None: p.kill(); p.wait()
