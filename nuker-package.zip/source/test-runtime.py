#!/usr/bin/env python3
"""Attach to real JVMs and verify packet bursts with mock Minecraft classes."""
import pathlib, subprocess, shutil
root=pathlib.Path(__file__).resolve().parent
jar=root/'dist/nuker-agent.jar'
def run_fixture(cp, options=None, limited=False):
 p=subprocess.Popen(['java','-cp',str(cp),'PacketFixture']+(['limited'] if limited else []),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  line=p.stdout.readline().strip();print(line)
  if not line.startswith('READY '):raise RuntimeError('fixture did not start')
  command=['java','--add-modules','jdk.attach','-jar',str(jar),line.split()[1],str(jar)]
  if options:command.append(options)
  subprocess.run(command,check=True,timeout=15)
  out,_=p.communicate(timeout=30);print(out,end='')
  if p.returncode!=0 or 'PASS ' not in out:raise RuntimeError('packet fixture failed')
 finally:
  if p.poll() is None:p.kill();p.wait()
cp=root/'build/test-classes'
run_fixture(cp)
run_fixture(cp,'radius=6,budget=2,interval=100',True)
fallback=root/'build/without-fabric-api'
if fallback.exists():shutil.rmtree(fallback)
shutil.copytree(cp,fallback);shutil.rmtree(fallback/'net/fabricmc')
run_fixture(fallback)
