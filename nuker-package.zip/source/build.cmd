@echo off
setlocal
cd /d "%~dp0"
if not exist build\classes mkdir build\classes
if not exist dist mkdir dist
javac --release 21 --add-modules jdk.attach -d build\classes src\nuker\*.java
if errorlevel 1 exit /b 1
>build\MANIFEST.MF echo Manifest-Version: 1.0
>>build\MANIFEST.MF echo Main-Class: nuker.Attach
>>build\MANIFEST.MF echo Agent-Class: nuker.Agent
>>build\MANIFEST.MF echo Can-Redefine-Classes: false
>>build\MANIFEST.MF echo Can-Retransform-Classes: false
>>build\MANIFEST.MF echo.
jar --create --file dist\nuker-agent.jar --manifest build\MANIFEST.MF -C build\classes .
