@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  java --add-modules jdk.attach -jar nuker-agent.jar --list
  echo.
  echo Usage: attach.cmd MinecraftPID
  echo Stop:  attach.cmd MinecraftPID stop
  exit /b
)
if "%~2"=="stop" (
  java --add-modules jdk.attach -jar nuker-agent.jar "%~1" "%~dp0nuker-agent.jar" stop
) else (
  java --add-modules jdk.attach -jar nuker-agent.jar "%~1" "%~dp0nuker-agent.jar" "radius=6,budget=128,interval=100"
)
