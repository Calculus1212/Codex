# Fabric 1.21.8 attachable nuker, version 3

Requires Java 21 with jdk.attach, Minecraft 1.21.8 and Fabric Loader using the intermediary namespace. Fabric API is optional. Other Minecraft versions and named development environments are not supported.

## Upgrade and use from Windows CMD

Restart Minecraft before attaching this version. An already-loaded Java agent cannot be replaced merely by overwriting its JAR. Extract the new nuker-package.zip into a new folder, and open CMD there. Start Minecraft and enter your world.

```cmd
attach.cmd
```

Find Minecraft's PID in the process list, then replace 12345 below:

```cmd
attach.cmd 12345
```

N toggles the nuker. End stops it until Minecraft restarts. It starts OFF, pauses for menus or lost focus, and switches OFF on world changes. Switching game mode keeps it enabled. N and End may conflict with existing bindings.

## Current behavior

Default scheduling interval is 100 ms. Radius remains 6 blocks and the budget remains 128 attempts per cycle. The actual radius is capped by the player's current block interaction range; this option does not grant extra reach. Work always runs on Minecraft's client thread, with at most one pending task. The main thread and server can delay actual processing.

The creative-only requirement has been removed. In creative, blocks are requested in batches using Minecraft's creative interactions, resetting the client creative cooldown between requests and restoring its previous value afterward.

In survival and other noncreative modes, the agent selects the nearest eligible block and keeps working on it across cycles until normal mining progress completes. Hard blocks take multiple cycles; instantly mineable blocks can be processed in a batch, up to the budget. Survival cooldowns, tools, block hardness, permissions, and server rules still apply. Mining progress is advanced at the configured interval, so the 100 ms setting may mine hard blocks more slowly than manually holding attack every game tick. This does not grant instant survival breaking. Adventure and spectator restrictions are enforced by the game.

Partial survival mining is cancelled when you turn the nuker off, open a menu, lose focus, stop the agent, or move the target out of reach. A world change clears the old target and switches the nuker OFF.

Targets are in a sphere around the player's eyes. Air and blocks with negative hardness are skipped. The scan order is reused while position and reach are unchanged, while current block states are checked each cycle.

## Configure

The launcher uses radius=6,budget=128,interval=100. To choose other values, attach directly:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar "radius=6,budget=128,interval=100"
```

Supported values: radius greater than 0 and at most 6; budget from 1 to 512; interval from 5 to 1000 milliseconds. Omitted options use the new defaults. You can reduce batch load with budget=32,interval=100. Restart Minecraft to change configuration after attachment.

Stop through CMD:

```cmd
attach.cmd 12345 stop
```

Run the command under the same OS user as Minecraft. If java is not on PATH, use the full path to a Java 21 installation with jdk.attach. If dynamic agent loading is disabled, add -XX:+EnableDynamicAgentLoading to Minecraft's JVM arguments and restart. Remove -XX:+DisableAttachMechanism if present. Java 21 normally prints a warning about dynamic agent loading.

## Source and verification

Java source and mock runtime tests are included in source/. Build on Windows with source\build.cmd or on Linux with source/build.sh. Requires a Java 21 JDK. There are no external build dependencies. Intermediary symbols were checked against FabricMC Yarn 1.21.8 mappings. The uploaded client-intermediary.jar exceeded the 32 MiB transfer limit and was not inspected.

source/test.sh builds and attaches the agent to real JVMs running mock Minecraft classes. Tests cover disabled startup, focus/menu handling, world changes, stopping, creative batch cooldown restoration, 128 removals per cycle, survival progress and completion, cancellation and resumption of partial mining, the 100 ms interval, player reach, and preventing a backlog during a busy frame. They run with and without mock Fabric API classes. They do not verify live Minecraft or server performance.
