# Fabric 1.21.8 attachable nuker, version 4

Requires Java 21 with jdk.attach, Minecraft 1.21.8 and Fabric Loader using the intermediary namespace. Fabric API is optional. Other Minecraft versions and named development environments are not supported.

## Upgrade and use from Windows CMD

Restart Minecraft before attaching this version. Overwriting a JAR does not replace an agent already loaded into Minecraft. Extract the new nuker-package.zip into a new folder, and open CMD there. Start Minecraft and enter your world.

```cmd
attach.cmd
```

Find Minecraft's PID, then replace 12345:

```cmd
attach.cmd 12345
```

N toggles the nuker. End stops it until Minecraft restarts. It starts OFF, pauses for menus or lost focus, and switches OFF on world changes. Switching game mode keeps it enabled.

## No-wait block requests

Version 4 sends a START_DESTROY_BLOCK packet followed immediately by a STOP_DESTROY_BLOCK packet for each non-air block in a sphere around the player's eyes. The sphere defaults to radius 6. It proceeds directly to the next block, with no retained mining target, progress updates, or wait for a block to break. If a block remains present in the client's world, it is attempted again in the next batch.

The default budget is 0, meaning every non-air block in the configured sphere is attempted each batch. There is no client-side game-mode, interaction-reach, or hardness filter. Radius still defines the area; air is skipped because there is no block to break there. The server decides which requests succeed, including its range and breaking-time rules. Sending requests does not force instant block removal. Requests rejected by the server can leave hard survival blocks unbroken.

The selected tool slot is synchronized before each batch. Requests use Minecraft's own sequenced-packet sender so the client/server sequence numbers remain valid. The agent does not force block removal in its local world.

A single daemon dispatches all game calls onto Minecraft's client thread. After a batch completes, it waits 100 ms before queuing the next batch. A busy client cannot accumulate extra queued batches. Stopping prevents further attempts; packets already sent are still processed by the server. Large batches increase client, network, and server load.

## Configure

Defaults and launcher settings:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar "radius=6,budget=0,interval=100"
```

Radius must be greater than 0 and at most 6. Budget 0 attempts all surrounding non-air blocks; a positive budget from 1 to 512 limits attempted blocks per batch, nearest first. Interval accepts 5 to 1000 milliseconds and is the delay after each completed batch. Restart Minecraft to change configuration after attachment.

Stop through CMD:

```cmd
attach.cmd 12345 stop
```

Run under the same OS user as Minecraft. If java is not on PATH, use a Java 21 installation with jdk.attach. If dynamic agent loading is disabled, add -XX:+EnableDynamicAgentLoading to Minecraft's JVM arguments and restart. Remove -XX:+DisableAttachMechanism if present. Java 21 normally prints a warning about dynamic agent loading.

## Source and verification

Source and mock runtime tests are in source/. Build on Windows with source\build.cmd, or on Linux with source/build.sh. Requires a Java 21 JDK and no external build dependencies. Packet and intermediary symbols were checked against FabricMC Yarn 1.21.8. The uploaded client-intermediary.jar exceeded the 32 MiB transfer limit and was not inspected.

source/test.sh attaches to real JVMs running mock Minecraft classes. A mock sender deliberately leaves every block unbroken, allowing tests to verify that all targets are still covered and retried without waiting. Tests check START/STOP ordering, sequence numbers, full sphere coverage, optional budget limits, attempts beyond player reach and on negative-hardness blocks, selected-slot synchronization, 100 ms scheduling, pause/stop behavior, world changes, and avoiding a task backlog. They run with and without mock Fabric API. Live Minecraft/server behavior remains untested.
