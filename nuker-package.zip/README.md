# Fabric 1.21.8 attachable block agent, version 6

Requires Java 21 with jdk.attach, Minecraft 1.21.8 and Fabric Loader in the intermediary namespace. Fabric API is optional.

This version sends START_DESTROY_BLOCK only. **START packets can still break instantly mineable blocks or creative-mode blocks. This is not a guaranteed nonbreaking interaction.** Server behavior determines the result. The agent does not force local block removal.

## Upgrade and use from Windows CMD

Restart Minecraft before attaching this version. Overwriting the JAR does not replace an already-loaded agent. Extract nuker-package.zip into a new folder, and open CMD there. Start Minecraft and enter your world.

```cmd
attach.cmd
```

Find Minecraft's PID, then replace 12345:

```cmd
attach.cmd 12345
```

N toggles requests. End stops the agent until Minecraft restarts. It starts OFF, pauses in menus or when unfocused, and turns OFF on world changes. Switching game mode keeps it enabled.

## START-only requests

Each batch sends one START_DESTROY_BLOCK packet for every non-air block in a sphere around the player's eyes. Radius defaults to 6. The agent sends no STOP_DESTROY_BLOCK or ABORT_DESTROY_BLOCK packets. It does not retain a mining target, advance mining progress, or wait for blocks to disappear. Blocks still present are attempted again in the next batch.

The delay after a completed batch is 1000 ms. All game calls run on the client thread, with no accumulating queue of pending batches.

The default budget is 0: all surrounding non-air blocks are attempted. There is no client-side game-mode, reach, or hardness filter. The server still enforces its own range, mining, and permission rules. Removing STOP packets does not change the meaning of START, which is a block attack request.

The selected tool slot is synchronized before each batch. START requests use Minecraft's sequenced-packet sender. Stopping the agent prevents new requests but does not recall packets already sent or send a cancellation packet. Large batches increase client, network, and server load.

## Configure

Default launcher settings:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar "radius=6,budget=0,interval=1000"
```

Radius must be greater than 0 and at most 6. Budget 0 covers all non-air blocks; a positive value from 1 to 512 limits targets per batch, nearest first. Interval accepts 5 to 1000 milliseconds and is the delay after each completed batch. Restart Minecraft to change an attached agent's configuration.

Stop through CMD:

```cmd
attach.cmd 12345 stop
```

Run under the same OS user as Minecraft. Use Java 21 with jdk.attach. If dynamic loading is disabled, add -XX:+EnableDynamicAgentLoading to Minecraft's JVM arguments and restart. Remove -XX:+DisableAttachMechanism if present. Java 21 normally prints a dynamic-agent warning.

## Source and verification

Source and mock tests are in source/. Build on Windows with source\build.cmd or on Linux with source/build.sh. Requires a Java 21 JDK; no external build dependencies. Intermediary symbols were checked against FabricMC Yarn 1.21.8. The uploaded client-intermediary.jar exceeded the 32 MiB transfer limit and was not inspected.

source/test.sh attaches to real JVMs with mock Minecraft classes, with and without mock Fabric API. Tests verify START-only actions with no STOP or ABORT, one request per target, increasing sequence numbers, full sphere coverage, optional batch limits, retries, slot synchronization, the 1000 ms interval, pause/stop behavior, world changes, and no accumulating task backlog. The mock does not remove blocks; it cannot establish nonbreaking behavior in live Minecraft. Live game/server compatibility remains untested.
