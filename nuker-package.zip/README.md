# Fabric 1.21.8 attachable nuker

Requires Java 21 with jdk.attach, Minecraft 1.21.8, and Fabric Loader using the intermediary namespace. Fabric API is optional. Other Minecraft versions and named development environments are not supported.

## Use from Windows CMD

Extract nuker-package.zip. Open CMD in the extracted folder. Start Minecraft and enter a creative world. Run:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar --list
```

Find Minecraft's process ID. Replace 12345 below:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar "radius=3,budget=8"
```

Alternatively, `attach.cmd` lists processes; `attach.cmd 12345` attaches.

N toggles the nuker. End stops it until Minecraft restarts. It starts OFF, pauses for menus or lost focus, and switches OFF on world changes or leaving creative mode. N and End may conflict with your existing bindings.

The nuker requests creative block breaks nearest first in a sphere around the player's eyes. Radius is limited by the player's actual interaction reach. Air and blocks with negative hardness are skipped. It resets the client creative breaking cooldown between requests and restores the original cooldown afterward. The server controls which requests succeed. It cannot force instant survival mining or override server protections.

Options: radius greater than 0 and at most 6; budget from 1 to 64 attempts per cycle. Default radius=3,budget=8. With Fabric API a cycle is an end-client tick; without it a daemon schedules client-thread work at most once every 50 ms, with only one pending task. All game and GLFW calls run on the client thread.

Stop through CMD:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar stop
```

Restart Minecraft to remove the passive listener or install with different options. This does not modify Minecraft JARs or transform game bytecode.

Run the attach command under the same OS user as Minecraft. If `java` is not on PATH, use the full path to a Java 21 installation with jdk.attach. If dynamic agent loading is disabled, add `-XX:+EnableDynamicAgentLoading` to Minecraft's JVM arguments and restart. Remove `-XX:+DisableAttachMechanism` if present. Java 21 normally prints a warning about dynamic agent loading.

## Verification and source

Source is included in source/. Build on Windows with source\build.cmd, or on Linux with source/build.sh. Requires a Java 21 JDK. Source is independent of external dependencies. Intermediary symbols were checked against FabricMC Yarn's 1.21.8 mappings. The uploaded client-intermediary.jar exceeded the 32 MiB transfer limit and was not inspected.

Real JVM attachment passed 15 behavior checks against mock Minecraft/Fabric classes, including startup, budget, player reach, creative gating, focus/menu handling, world changes and stopping. A separate fixture without Fabric API passed attachment, multiple creative breaks despite cooldown, and external stop checks. These are mock runtime tests, not a live Minecraft or server test.
