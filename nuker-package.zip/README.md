# Fabric 1.21.8 attachable nuker, version 2

Requires Java 21 with jdk.attach, Minecraft 1.21.8 and Fabric Loader using the intermediary namespace. Fabric API is optional. Other Minecraft versions and named development environments are not supported.

## Upgrade and use from Windows CMD

Restart Minecraft before attaching this version. An already-loaded Java agent cannot be replaced merely by overwriting its JAR. Extract the new nuker-package.zip into a new folder, and open CMD there. Start Minecraft and enter a creative world.

```cmd
attach.cmd
```

Find Minecraft's PID in the process list, then replace 12345 below:

```cmd
attach.cmd 12345
```

N toggles the nuker. End stops it until Minecraft restarts. It starts OFF, pauses for menus or lost focus, and switches OFF on world changes or leaving creative mode. N and End may conflict with existing bindings.

## Faster, larger defaults

Requested radius increased from 3 to 6 blocks. The actual radius is still capped by the player's current block interaction range. Changing this option does not grant extra reach.

Breaking budget increased from 8 to 128 attempts per cycle. Scheduling interval decreased from approximately 50 ms to 10 ms. This applies with or without Fabric API, with work always executed on Minecraft's client thread. The main thread and server can delay actual processing. The scan's geometric target order is reused while the player's position and reach remain unchanged; current block states are still checked on every cycle.

The agent requests normal creative block breaks nearest first in a sphere around the player's eyes. It resets the client creative cooldown between requests and restores its previous value afterward. Air and blocks with negative hardness are skipped. The server controls which requests succeed; this cannot force instant survival mining or override server protections. Larger batches may reduce performance depending on the world and server.

One scheduled task may be pending at a time. Tasks do not build up while the client is busy, and queued work checks the stop flag before breaking blocks.

## Configure

The launcher uses radius=6,budget=128,interval=10. To choose other values, attach directly:

```cmd
java --add-modules jdk.attach -jar nuker-agent.jar 12345 nuker-agent.jar "radius=6,budget=128,interval=10"
```

Supported values: radius greater than 0 and at most 6; budget from 1 to 512; interval from 5 to 1000 milliseconds. Omitted options use the new defaults. You can reduce load with budget=32,interval=25. Restart Minecraft to change configuration after attachment.

Stop through CMD:

```cmd
attach.cmd 12345 stop
```

Run the command under the same OS user as Minecraft. If java is not on PATH, use the full path to a Java 21 installation with jdk.attach. If dynamic agent loading is disabled, add -XX:+EnableDynamicAgentLoading to Minecraft's JVM arguments and restart. Remove -XX:+DisableAttachMechanism if present. Java 21 normally prints a warning about dynamic agent loading.

## Source and verification

Java source and mock runtime tests are included in source/. Build on Windows with source\build.cmd or on Linux with source/build.sh. Requires a Java 21 JDK. There are no external build dependencies. Intermediary symbols were checked against FabricMC Yarn 1.21.8 mappings. The uploaded client-intermediary.jar exceeded the 32 MiB transfer limit and was not inspected.

source/test.sh builds and attaches the agent to real JVMs running mock Minecraft classes. Tests cover disabled startup, focus/menu handling, creative gating, world changes, stopping, cooldown restoration, 128 removals per cycle, breaking beyond the old radius while respecting player reach, and preventing a backlog during a busy frame. They run with and without mock Fabric API classes. They do not verify live Minecraft or server performance.
