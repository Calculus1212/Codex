package planter;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Runtime attachment for Fabric 1.21.8 intermediary namespace. No bytecode patches. */
public final class Agent {
    private static final String INSTALLED = "planter.agent.installed";
    private static final String STOP = "planter.agent.stop";
    public static void agentmain(String options, Instrumentation instrumentation) throws Exception {
        if ("stop".equals(options)) { System.setProperty(STOP, "true"); return; }
        Config config = Config.parse(options);
        synchronized (Agent.class) {
            if (System.getProperty(INSTALLED) != null)
                throw new IllegalStateException("Already attached. Use END to stop or attach with 'stop'. Restart Minecraft to reinstall.");
            Class<?> minecraft = Arrays.stream(instrumentation.getAllLoadedClasses())
                .filter(c -> c.getName().equals("net.minecraft.class_310")).findFirst()
                .orElseThrow(() -> new IllegalStateException("No running intermediary Minecraft client found."));
            Object client = minecraft.getMethod("method_1551").invoke(null);
            ClassLoader loader = minecraft.getClassLoader();
            Hooks hooks = new Hooks(loader, config);
            // Use client-thread tasks between ticks, including when Fabric API is present.
            // Keeping a single pending task prevents bursts after a busy frame or pause.
            Runnable install = () -> {
                ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "Planter schedule"); t.setDaemon(true); return t;
                });
                class Dispatch implements Runnable {
                    @Override public void run() {
                        if (hooks.stopped) { timer.shutdown(); return; }
                        try {
                            ((Executor)client).execute(() -> {
                                try { hooks.tick(client); }
                                finally {
                                    if (hooks.stopped) timer.shutdown();
                                    else timer.schedule(this, config.interval, TimeUnit.MILLISECONDS);
                                }
                            });
                        } catch (RuntimeException failure) {
                            hooks.stopped = true; timer.shutdown();
                            System.err.println("[Planter] Stopped after scheduling failure: " + failure);
                        }
                    }
                }
                timer.schedule(new Dispatch(), 0, TimeUnit.MILLISECONDS);
            };
            CompletableFuture<Void> ready = new CompletableFuture<>();
            System.setProperty(INSTALLED, "installing");
            System.clearProperty(STOP);
            Runnable finalInstall = install;
            try {
                ((Executor)client).execute(() -> {
                    try {
                        if (Boolean.getBoolean(STOP)) throw new IllegalStateException("Attachment cancelled");
                        finalInstall.run();
                        System.setProperty(INSTALLED, "true");
                        System.out.println("[Planter] Attached, OFF. P toggles; END stops. Radius=" + config.radius + ", attempts/cycle=" + (config.budget == 0 ? "all" : config.budget) + ", interval=" + config.interval + "ms");
                        ready.complete(null);
                    } catch (Throwable e) { System.clearProperty(INSTALLED); ready.completeExceptionally(e); }
                });
                ready.get(10, TimeUnit.SECONDS);
            } catch (Exception failure) {
                System.setProperty(STOP, "true");
                System.clearProperty(INSTALLED);
                throw failure;
            }
        }
    }

    record Config(double radius, int budget, int interval, int retry, String item) {
        static Config parse(String text) {
            double radius = 5; int budget = 0, interval = 100, retry = 1000;
            String item = "erazion:experience_seeds";
            if (text != null && !text.isBlank()) for (String option : text.split(",")) {
                String[] pair = option.trim().split("=", -1);
                if (pair.length != 2) throw new IllegalArgumentException("Expected radius=5,budget=0,interval=100 or stop");
                switch (pair[0]) {
                    case "radius" -> radius = Double.parseDouble(pair[1]);
                    case "budget" -> budget = Integer.parseInt(pair[1]);
                    case "interval" -> interval = Integer.parseInt(pair[1]);
                    case "retry" -> retry = Integer.parseInt(pair[1]);
                    case "item" -> item = pair[1];
                    default -> throw new IllegalArgumentException("Unknown option: " + pair[0]);
                }
            }
            if (!Double.isFinite(radius) || radius <= 0 || radius > 5 || budget < 0 || budget > 512
                    || interval < 20 || interval > 1000 || retry < interval || retry > 10000
                    || !item.matches("[a-z0-9_.-]+:[a-z0-9_./-]+"))
                throw new IllegalArgumentException("radius must be >0..5, budget 0..512, interval 20..1000 ms, retry interval..10000 ms, and item a namespaced ID");
            return new Config(radius, budget, interval, retry, item);
        }
    }

    static final class Hooks {
        final Config config;
        final Field player, world, manager, screen, vx, vy, vz;
        final Method focused, window, handle, key, eye, state, getBlock, isAir, heldStack, getItem, isEmpty, getCount, registryId, sendSequenced, syncSelected;
        final Constructor<?> blockPos, hitResult, vector, packet;
        final Class<?> creator;
        final ClassLoader loader;
        final Object mainHand, up, blockRegistry, itemRegistry;
        final Map<Target, Long> attemptedAt = new HashMap<>();
        boolean enabled, previousToggle;
        volatile boolean stopped;
        Object lastWorld;
        Hooks(ClassLoader loader, Config config) throws Exception {
            this.config = config; this.loader = loader;
            Class<?> mc = Class.forName("net.minecraft.class_310", false, loader);
            Class<?> entity = Class.forName("net.minecraft.class_1297", false, loader);
            Class<?> living = Class.forName("net.minecraft.class_1309", false, loader);
            Class<?> stack = Class.forName("net.minecraft.class_1799", false, loader);
            Class<?> hand = Class.forName("net.minecraft.class_1268", false, loader);
            Class<?> hit = Class.forName("net.minecraft.class_3965", false, loader);
            Class<?> pos = Class.forName("net.minecraft.class_2338", false, loader);
            Class<?> direction = Class.forName("net.minecraft.class_2350", false, loader);
            Class<?> view = Class.forName("net.minecraft.class_1922", false, loader);
            Class<?> bs = Class.forName("net.minecraft.class_2680", false, loader);
            Class<?> vec = Class.forName("net.minecraft.class_243", false, loader);
            player = mc.getField("field_1724"); world = mc.getField("field_1687");
            manager = mc.getField("field_1761"); screen = mc.getField("field_1755");
            focused = mc.getMethod("method_1569"); window = mc.getMethod("method_22683");
            handle = Class.forName("net.minecraft.class_1041", false, loader).getMethod("method_4490");
            key = Class.forName("org.lwjgl.glfw.GLFW", false, loader).getMethod("glfwGetKey", long.class, int.class);
            eye = entity.getMethod("method_33571");
            state = view.getMethod("method_8320", pos); getBlock = bs.getMethod("method_26204");
            isAir = bs.getMethod("method_26215");
            heldStack = living.getMethod("method_6047");
            getItem = stack.getMethod("method_7909");
            isEmpty = stack.getMethod("method_7960");
            getCount = stack.getMethod("method_7947");
            Class<?> registries = Class.forName("net.minecraft.class_7923", false, loader);
            blockRegistry = registries.getField("field_41175").get(null);
            itemRegistry = registries.getField("field_41178").get(null);
            registryId = Class.forName("net.minecraft.class_2378", false, loader).getMethod("method_10221", Object.class);
            Class<?> interaction = Class.forName("net.minecraft.class_636", false, loader);
            creator = Class.forName("net.minecraft.class_7204", false, loader);
            sendSequenced = interaction.getDeclaredMethod("method_41931", Class.forName("net.minecraft.class_638", false, loader), creator);
            sendSequenced.setAccessible(true);
            syncSelected = interaction.getDeclaredMethod("method_2911"); syncSelected.setAccessible(true);
            mainHand = constant(hand, "MAIN_HAND"); up = constant(direction, "UP");
            packet = Class.forName("net.minecraft.class_2885", false, loader).getConstructor(hand, hit, int.class);
            hitResult = hit.getConstructor(vec, direction, pos, boolean.class);
            vector = vec.getConstructor(double.class, double.class, double.class);
            blockPos = pos.getConstructor(int.class, int.class, int.class);
            vx = vec.getField("field_1352"); vy = vec.getField("field_1351"); vz = vec.getField("field_1350");
        }
        static Object constant(Class<?> actionType, String name) {
            return Arrays.stream(actionType.getEnumConstants()).filter(value -> ((Enum<?>)value).name().equals(name))
                .findFirst().orElseThrow(() -> new IllegalStateException("Missing enum constant: " + name));
        }
        void send(Object m, Object w, Object hit) throws ReflectiveOperationException {
            Object factory = Proxy.newProxyInstance(loader, new Class<?>[]{creator}, (proxy, method, args) -> {
                if (method.getName().equals("predict")) return packet.newInstance(mainHand, hit, (int)args[0]);
                if (method.getName().equals("toString")) return "Planter block packet creator";
                if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                if (method.getName().equals("equals")) return proxy == args[0];
                throw new UnsupportedOperationException(method.toString());
            });
            sendSequenced.invoke(m, w, factory);
        }
        boolean farmland(Object stateValue) throws ReflectiveOperationException {
            return "minecraft:farmland".equals(String.valueOf(registryId.invoke(blockRegistry, getBlock.invoke(stateValue))));
        }
        void tick(Object client) {
            if (stopped) return;
            try {
                Object w = world.get(client), p = player.get(client), m = manager.get(client);
                if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                boolean active = (boolean)focused.invoke(client);
                long id = (long)handle.invoke(window.invoke(client));
                if (active && (int)key.invoke(null, id, 269) == 1) {
                    stopped = true; enabled = false; System.out.println("[Planter] Stopped until Minecraft restarts."); return;
                }
                boolean toggle = active && (int)key.invoke(null, id, 80) == 1;
                if (w != lastWorld) { enabled = false; lastWorld = w; attemptedAt.clear(); }
                if (toggle && !previousToggle && screen.get(client) == null && p != null && w != null) {
                    enabled = !enabled; attemptedAt.clear();
                    Object held = heldStack.invoke(p);
                    System.out.println("[Planter] " + (enabled ? "ON" : "OFF") + "; holding " + registryId.invoke(itemRegistry, getItem.invoke(held)) + "; required " + config.item);
                }
                previousToggle = toggle;
                if (!enabled || !active || screen.get(client) != null || p == null || w == null || m == null) return;
                Object held = heldStack.invoke(p);
                if ((boolean)isEmpty.invoke(held) || !config.item.equals(String.valueOf(registryId.invoke(itemRegistry, getItem.invoke(held))))) return;
                int limit = (int)getCount.invoke(held);
                if (config.budget > 0) limit = Math.min(limit, config.budget);
                if (limit <= 0) return;
                Object eyes = eye.invoke(p);
                double x = vx.getDouble(eyes), y = vy.getDouble(eyes), z = vz.getDouble(eyes);
                long now = System.nanoTime();
                long retryNanos = TimeUnit.MILLISECONDS.toNanos(config.retry);
                attemptedAt.entrySet().removeIf(e -> now - e.getValue() >= retryNanos);
                // One unacknowledged planting attempt reserves one held seed. Release it when
                // the crop appears, the soil disappears, the player moves away, or retry expires.
                for (Iterator<Target> pending = attemptedAt.keySet().iterator(); pending.hasNext();) {
                    Target t = pending.next();
                    Object ground = state.invoke(w, blockPos.newInstance(t.x, t.y, t.z));
                    Object above = state.invoke(w, blockPos.newInstance(t.x, t.y+1, t.z));
                    if (!(boolean)isAir.invoke(above) || !farmland(ground)
                            || distanceSquared(x, y, z, t.x, t.y, t.z) > config.radius*config.radius) pending.remove();
                }
                limit = Math.min(limit, Math.max(0, (int)getCount.invoke(held) - attemptedAt.size()));
                if (limit <= 0) return;
                boolean synchronizedSlot = false;
                int attempted = 0;
                for (Target t : targets(x, y, z, config.radius)) {
                    if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                    if (attemptedAt.containsKey(t)) continue;
                    Object pos = blockPos.newInstance(t.x, t.y, t.z);
                    if (!farmland(state.invoke(w, pos))) continue;
                    if (!(boolean)isAir.invoke(state.invoke(w, blockPos.newInstance(t.x, t.y+1, t.z)))) continue;
                    Object current = heldStack.invoke(p);
                    if ((boolean)isEmpty.invoke(current) || !config.item.equals(String.valueOf(registryId.invoke(itemRegistry, getItem.invoke(current))))) return;
                    if (!synchronizedSlot) { syncSelected.invoke(m); synchronizedSlot = true; }
                    Object hit = hitResult.newInstance(vector.newInstance(t.x+.5, t.y+.9375, t.z+.5), up, pos, false);
                    send(m, w, hit);
                    attemptedAt.put(t, now);
                    // Send the whole eligible batch without waiting for placement acknowledgements.
                    if (++attempted >= limit) break;
                }
            } catch (Throwable e) {
                stopped = true; enabled = false;
                System.err.println("[Planter] Stopped after runtime failure: " + e);
                e.printStackTrace(System.err);
            }
        }
    }
    record Target(int x, int y, int z) {}
    static double distanceSquared(double x, double y, double z, int bx, int by, int bz) {
        return (bx+.5-x)*(bx+.5-x)+(by+.9375-y)*(by+.9375-y)+(bz+.5-z)*(bz+.5-z);
    }
    static List<Target> targets(double x, double y, double z, double r) {
        List<Target> result = new ArrayList<>();
        for (int bx=(int)Math.floor(x-r); bx<=Math.floor(x+r); bx++)
            for (int by=(int)Math.floor(y-r)-1; by<=Math.floor(y+r); by++)
                for (int bz=(int)Math.floor(z-r); bz<=Math.floor(z+r); bz++) {
                    if (distanceSquared(x, y, z, bx, by, bz) <= r*r) result.add(new Target(bx, by, bz));
                }
        result.sort(Comparator.comparingDouble(t -> distanceSquared(x, y, z, t.x, t.y, t.z)));
        return result;
    }
}
