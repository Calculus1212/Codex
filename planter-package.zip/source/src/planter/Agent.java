package planter;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.*;
import java.util.*;
import java.util.concurrent.*;

/** Runtime attachment for Fabric 1.21.8 intermediary namespace. No bytecode patches. */
public final class Agent {
    private static final String INSTALLED = "planter.agent.installed";
    private static final String STOP = "planter.agent.stop";
    private static volatile Hooks installedHooks;
    private static final SettingsWindow window = new SettingsWindow();
    static Config currentSettings() {
        Hooks hooks = installedHooks;
        if (hooks == null || hooks.stopped) throw new IllegalStateException("Attach the agent before opening settings.");
        return hooks.config;
    }
    static void updateSettings(Config next) {
        Hooks hooks = installedHooks;
        if (hooks == null || hooks.stopped) throw new IllegalStateException("The agent is stopped. Restart Minecraft and attach again.");
        hooks.config = next;
    }
    static boolean isStopped() { Hooks hooks = installedHooks; return hooks == null || hooks.stopped; }
    static void showSettings() { window.show(Agent::currentSettings, Agent::updateSettings, Agent::isStopped); }
    public static void agentmain(String options, Instrumentation instrumentation) throws Exception {
        if ("stop".equals(options)) { System.setProperty(STOP, "true"); window.dispose(); return; }
        if ("gui".equals(options)) { currentSettings(); showSettings(); return; }
        Config config = Config.parse(options);
        synchronized (Agent.class) {
            if (System.getProperty(INSTALLED) != null)
                throw new IllegalStateException("Already attached. Use END to stop or attach with 'stop'. Restart Minecraft to reinstall.");
            Class<?> minecraft = Arrays.stream(instrumentation.getAllLoadedClasses())
                .filter(c -> c.getName().equals("net.minecraft.class_310")).findFirst()
                .orElseThrow(() -> new IllegalStateException("No running intermediary Minecraft client found."));
            Object client = minecraft.getMethod("method_1551").invoke(null);
            ClassLoader loader = minecraft.getClassLoader();
            Hooks hooks = new Hooks(loader, config);
            // Use client-thread tasks between ticks, including when Fabric API is present.
            // Keeping a single pending task prevents bursts after a busy frame or pause.
            Runnable install = () -> {
                ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(r -> {
                    Thread t = new Thread(r, "Planter schedule"); t.setDaemon(true); return t;
                });
                class Dispatch implements Runnable {
                    @Override public void run() {
                        if (hooks.stopped) { timer.shutdown(); window.dispose(); return; }
                        try {
                            ((Executor)client).execute(() -> {
                                try { hooks.tick(client); }
                                finally {
                                    if (hooks.stopped) { timer.shutdown(); window.dispose(); }
                                    else timer.schedule(this, hooks.config.interval, TimeUnit.MILLISECONDS);
                                }
                            });
                        } catch (RuntimeException failure) {
                            hooks.stopped = true; timer.shutdown(); window.dispose();
                            System.err.println("[Planter] Stopped after scheduling failure: " + failure);
                        }
                    }
                }
                timer.schedule(new Dispatch(), 0, TimeUnit.MILLISECONDS);
            };
            CompletableFuture<Void> ready = new CompletableFuture<>();
            System.setProperty(INSTALLED, "installing");
            System.clearProperty(STOP);
            Runnable finalInstall = install;
            try {
                ((Executor)client).execute(() -> {
                    try {
                        if (Boolean.getBoolean(STOP)) throw new IllegalStateException("Attachment cancelled");
                        finalInstall.run();
                        installedHooks = hooks;
                        System.setProperty(INSTALLED, "true");
                        System.out.println("[Planter] Attached, OFF. P toggles; END stops. Radius=" + config.radius + ", attempts/cycle=" + (config.budget == 0 ? 70 : config.budget) + ", interval=" + config.interval + "ms");
                        ready.complete(null);
                    } catch (Throwable e) { System.clearProperty(INSTALLED); ready.completeExceptionally(e); }
                });
                ready.get(10, TimeUnit.SECONDS);
                showSettings();
            } catch (Exception failure) {
                System.setProperty(STOP, "true");
                System.clearProperty(INSTALLED);
                throw failure;
            }
        }
    }

    record Config(double radius, int budget, int interval, int retry) {
        Config {
            if (!Double.isFinite(radius) || radius <= 0 || radius > 8)
                throw new IllegalArgumentException("Range must be greater than 0 and at most 8 blocks.");
            if (budget < 0 || budget > 70)
                throw new IllegalArgumentException("Requests must be 1 to 70; CLI 0 also means 70.");
            if (interval < 20 || interval > 1000)
                throw new IllegalArgumentException("Delay must be 20 to 1000 milliseconds.");
            if (retry < interval || retry > 10000)
                throw new IllegalArgumentException("Retry must be at least the delay and at most 10000 ms.");
        }
        static Config parse(String text) {
            double radius = 8; int budget = 70, interval = 100, retry = 100;
            boolean customRetry = false;
            if (text != null && !text.isBlank()) for (String option : text.split(",")) {
                String[] pair = option.trim().split("=", -1);
                if (pair.length != 2) throw new IllegalArgumentException("Expected radius=8,budget=70,interval=100 or stop");
                switch (pair[0]) {
                    case "radius" -> radius = Double.parseDouble(pair[1]);
                    case "budget" -> budget = Integer.parseInt(pair[1]);
                    case "interval" -> interval = Integer.parseInt(pair[1]);
                    case "retry" -> { retry = Integer.parseInt(pair[1]); customRetry = true; }
                    default -> throw new IllegalArgumentException("Unknown option: " + pair[0]);
                }
            }
            return new Config(radius, budget, interval, customRetry ? retry : Math.max(100, interval));
        }
    }

    static final class Hooks {
        volatile Config config;
        final Field player, world, manager, screen, vx, vy, vz;
        final Method focused, window, handle, key, eye, feetY, state, isAir, collisionShape, shapeEmpty, shapeMax, heldStack, isEmpty, sendSequenced, syncSelected;
        final Constructor<?> blockPos, hitResult, vector, packet;
        final Class<?> creator;
        final ClassLoader loader;
        final Object mainHand, up, axisY;
        final Map<Target, Long> attemptedAt = new HashMap<>();
        List<Target> sweep;
        int nextTarget, sweepBlockX, sweepBlockZ, sweepY;
        double sweepRadius;
        boolean enabled, previousToggle, previousGui;
        volatile boolean stopped;
        Object lastWorld;
        Hooks(ClassLoader loader, Config config) throws Exception {
            this.config = config; this.loader = loader;
            Class<?> mc = Class.forName("net.minecraft.class_310", false, loader);
            Class<?> entity = Class.forName("net.minecraft.class_1297", false, loader);
            Class<?> living = Class.forName("net.minecraft.class_1309", false, loader);
            Class<?> stack = Class.forName("net.minecraft.class_1799", false, loader);
            Class<?> hand = Class.forName("net.minecraft.class_1268", false, loader);
            Class<?> hit = Class.forName("net.minecraft.class_3965", false, loader);
            Class<?> pos = Class.forName("net.minecraft.class_2338", false, loader);
            Class<?> direction = Class.forName("net.minecraft.class_2350", false, loader);
            Class<?> view = Class.forName("net.minecraft.class_1922", false, loader);
            Class<?> bs = Class.forName("net.minecraft.class_2680", false, loader);
            Class<?> vec = Class.forName("net.minecraft.class_243", false, loader);
            player = mc.getField("field_1724"); world = mc.getField("field_1687");
            manager = mc.getField("field_1761"); screen = mc.getField("field_1755");
            focused = mc.getMethod("method_1569"); window = mc.getMethod("method_22683");
            handle = Class.forName("net.minecraft.class_1041", false, loader).getMethod("method_4490");
            key = Class.forName("org.lwjgl.glfw.GLFW", false, loader).getMethod("glfwGetKey", long.class, int.class);
            eye = entity.getMethod("method_33571"); feetY = entity.getMethod("method_23318");
            state = view.getMethod("method_8320", pos);
            isAir = bs.getMethod("method_26215");
            heldStack = living.getMethod("method_6047");
            isEmpty = stack.getMethod("method_7960");
            Class<?> shape = Class.forName("net.minecraft.class_265", false, loader);
            Class<?> axis = Class.forName("net.minecraft.class_2350$class_2351", false, loader);
            collisionShape = bs.getMethod("method_26220", view, pos);
            shapeEmpty = shape.getMethod("method_1110"); shapeMax = shape.getMethod("method_1105", axis);
            axisY = constant(axis, "Y");
            Class<?> interaction = Class.forName("net.minecraft.class_636", false, loader);
            creator = Class.forName("net.minecraft.class_7204", false, loader);
            sendSequenced = interaction.getDeclaredMethod("method_41931", Class.forName("net.minecraft.class_638", false, loader), creator);
            sendSequenced.setAccessible(true);
            syncSelected = interaction.getDeclaredMethod("method_2911"); syncSelected.setAccessible(true);
            mainHand = constant(hand, "MAIN_HAND"); up = constant(direction, "UP");
            packet = Class.forName("net.minecraft.class_2885", false, loader).getConstructor(hand, hit, int.class);
            hitResult = hit.getConstructor(vec, direction, pos, boolean.class);
            vector = vec.getConstructor(double.class, double.class, double.class);
            blockPos = pos.getConstructor(int.class, int.class, int.class);
            vx = vec.getField("field_1352"); vy = vec.getField("field_1351"); vz = vec.getField("field_1350");
        }
        static Object constant(Class<?> actionType, String name) {
            return Arrays.stream(actionType.getEnumConstants()).filter(value -> ((Enum<?>)value).name().equals(name))
                .findFirst().orElseThrow(() -> new IllegalStateException("Missing enum constant: " + name));
        }
        void send(Object m, Object w, Object hit) throws ReflectiveOperationException {
            Object factory = Proxy.newProxyInstance(loader, new Class<?>[]{creator}, (proxy, method, args) -> {
                if (method.getName().equals("predict")) return packet.newInstance(mainHand, hit, (int)args[0]);
                if (method.getName().equals("toString")) return "Planter block packet creator";
                if (method.getName().equals("hashCode")) return System.identityHashCode(proxy);
                if (method.getName().equals("equals")) return proxy == args[0];
                throw new UnsupportedOperationException(method.toString());
            });
            sendSequenced.invoke(m, w, factory);
        }
        void tick(Object client) {
            if (stopped) return;
            try {
                Config settings = config;
                Object w = world.get(client), p = player.get(client), m = manager.get(client);
                if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                boolean active = (boolean)focused.invoke(client);
                long id = (long)handle.invoke(window.invoke(client));
                if (active && (int)key.invoke(null, id, 269) == 1) {
                    stopped = true; enabled = false; System.out.println("[Planter] Stopped until Minecraft restarts."); return;
                }
                boolean openGui = active && (int)key.invoke(null, id, 79) == 1;
                if (openGui && !previousGui && screen.get(client) == null) showSettings();
                previousGui = openGui;
                boolean toggle = active && (int)key.invoke(null, id, 80) == 1;
                if (w != lastWorld) { enabled = false; lastWorld = w; attemptedAt.clear(); sweep = null; nextTarget = 0; }
                if (toggle && !previousToggle && screen.get(client) == null && p != null && w != null) {
                    enabled = !enabled; attemptedAt.clear(); sweep = null; nextTarget = 0;
                    System.out.println("[Planter] " + (enabled ? "ON" : "OFF"));
                }
                previousToggle = toggle;
                if (!enabled || !active || screen.get(client) != null || p == null || w == null || m == null) return;
                Object held = heldStack.invoke(p);
                if ((boolean)isEmpty.invoke(held)) return;
                int limit = settings.budget == 0 ? 70 : settings.budget;
                Object eyes = eye.invoke(p);
                double x = vx.getDouble(eyes), y = vy.getDouble(eyes), z = vz.getDouble(eyes);
                int supportY = (int)Math.floor(Math.nextDown((double)feetY.invoke(p)));
                long now = System.nanoTime();
                long retryNanos = TimeUnit.MILLISECONDS.toNanos(settings.retry);
                attemptedAt.entrySet().removeIf(e -> now - e.getValue() >= retryNanos);
                int centerBlockX = (int)Math.floor(x), centerBlockZ = (int)Math.floor(z);
                if (sweep == null || sweepBlockX != centerBlockX || sweepBlockZ != centerBlockZ || sweepY != supportY || sweepRadius != settings.radius) {
                    if (sweepRadius != settings.radius) attemptedAt.clear();
                    sweep = targets(x, z, supportY, settings.radius);
                    nextTarget = 0;
                    sweepBlockX = centerBlockX; sweepBlockZ = centerBlockZ; sweepY = supportY; sweepRadius = settings.radius;
                }
                boolean synchronizedSlot = false;
                int attempted = 0;
                while (nextTarget < sweep.size() && attempted < limit) {
                    if (Boolean.getBoolean(STOP)) { stopped = true; enabled = false; return; }
                    Object current = heldStack.invoke(p);
                    if ((boolean)isEmpty.invoke(current)) return;
                    Target t = sweep.get(nextTarget++);
                    if (attemptedAt.containsKey(t)) continue;
                    Object pos = blockPos.newInstance(t.x, t.y, t.z);
                    Object ground = state.invoke(w, pos);
                    if ((boolean)isAir.invoke(ground)) continue;
                    Object shape = collisionShape.invoke(ground, w, pos);
                    if ((boolean)shapeEmpty.invoke(shape)) continue;
                    double top = (double)shapeMax.invoke(shape, axisY);
                    if (!Double.isFinite(top) || top <= 0 || top > 1) continue;
                    if (distanceSquared(x, y, z, t.x+.5, t.y+top, t.z+.5) > settings.radius*settings.radius) continue;
                    if (!(boolean)isAir.invoke(state.invoke(w, blockPos.newInstance(t.x, t.y+1, t.z)))) continue;
                    if (!synchronizedSlot) { syncSelected.invoke(m); synchronizedSlot = true; }
                    Object hit = hitResult.newInstance(vector.newInstance(t.x+.5, t.y+top, t.z+.5), up, pos, false);
                    send(m, w, hit);
                    attemptedAt.put(t, now);
                    // Send the whole eligible batch without waiting for placement acknowledgements.
                    attempted++;
                }
                // Finish this pass before starting again at the nearest block in a later batch.
                if (nextTarget >= sweep.size()) {
                    sweep = null; nextTarget = 0;
                }
            } catch (Throwable e) {
                stopped = true; enabled = false;
                System.err.println("[Planter] Stopped after runtime failure: " + e);
                e.printStackTrace(System.err);
            }
        }
    }
    record Target(int x, int y, int z) {}
    static double distanceSquared(double x, double y, double z, double hx, double hy, double hz) {
        return (hx-x)*(hx-x)+(hy-y)*(hy-y)+(hz-z)*(hz-z);
    }
    static List<Target> targets(double x, double z, int supportY, double r) {
        List<Target> result = new ArrayList<>();
        for (int bx=(int)Math.floor(x-r); bx<=Math.floor(x+r); bx++)
            for (int bz=(int)Math.floor(z-r); bz<=Math.floor(z+r); bz++) {
                double dx=bx+.5-x, dz=bz+.5-z;
                if (dx*dx+dz*dz <= r*r) result.add(new Target(bx, supportY, bz));
            }
        result.sort(Comparator.comparingDouble(t -> (t.x+.5-x)*(t.x+.5-x)+(t.z+.5-z)*(t.z+.5-z)));
        return result;
    }
}
