package planter;

import com.sun.tools.attach.VirtualMachine;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.nio.file.Path;
import java.util.Properties;
import java.util.concurrent.*;

/** Settings hosted in the CMD Java process, independent of Minecraft's headless AWT state. */
final class RemoteSettings implements AutoCloseable {
    private final VirtualMachine vm;
    private final String jar;
    private final ScheduledExecutorService polling = Executors.newSingleThreadScheduledExecutor(task -> {
        Thread thread = new Thread(task, "Planter settings connection"); thread.setDaemon(true); return thread;
    });
    private volatile Agent.Config settings;
    private volatile boolean stopped;
    private boolean closed;

    RemoteSettings(String pid, String jar) throws Exception {
        this.jar = Path.of(jar).toAbsolutePath().toString();
        vm = VirtualMachine.attach(pid);
        try { refresh(); }
        catch (Exception failure) { vm.detach(); throw failure; }
        if (stopped) { vm.detach(); throw new IllegalStateException("Agent stopped. Restart Minecraft and attach again."); }
    }
    static void open(String pid, String jar) throws Exception {
        if (GraphicsEnvironment.isHeadless()) throw new IllegalStateException(
            "The CMD Java also reports no desktop. Run attach.cmd from a Windows desktop with Java 21; the script sets -Djava.awt.headless=false.");
        RemoteSettings remote = new RemoteSettings(pid, jar);
        SettingsWindow window = new SettingsWindow(remote::close);
        window.show(remote::current, remote::apply, remote::isStopped);
        remote.polling.scheduleWithFixedDelay(() -> {
            try { remote.refresh(); }
            catch (Exception failure) {
                remote.stopped = true;
                System.err.println("[Planter GUI] Game connection closed: " + failure.getMessage());
            }
            if (remote.stopped) { window.dispose(); remote.close(); }
        }, 750, 750, TimeUnit.MILLISECONDS);
        System.out.println("External Replanter settings opened. Keep this CMD open while using the window.");
    }
    synchronized void refresh() throws Exception {
        if (closed) return;
        Properties properties = vm.getSystemProperties();
        if (!Agent.VERSION.equals(properties.getProperty("planter.agent.version")))
            throw new IllegalStateException("Different planter version loaded. Restart Minecraft and attach this package again.");
        stopped = Boolean.parseBoolean(properties.getProperty("planter.agent.stop"))
            || !"true".equals(properties.getProperty("planter.agent.installed"));
        if (!stopped) {
            String encoded = properties.getProperty("planter.agent.settings");
            if (encoded == null) throw new IllegalStateException("The attached agent did not publish settings.");
            settings = Agent.Config.parse(encoded);
        }
    }
    Agent.Config current() { return settings; }
    boolean isStopped() { return stopped; }
    synchronized void apply(Agent.Config next) {
        if (closed || stopped) throw new IllegalStateException("Game connection closed. Reattach to reopen settings.");
        try {
            vm.loadAgent(jar, "settings=" + next.encode());
            refresh();
            if (stopped) throw new IllegalStateException("Agent stopped before applying settings.");
        } catch (Exception failure) {
            String detail = failure.getMessage();
            try { detail = vm.getSystemProperties().getProperty("planter.agent.error", detail); }
            catch (Exception ignored) { }
            throw new IllegalStateException("Could not apply settings: " + detail, failure);
        }
    }
    @Override public synchronized void close() {
        if (closed) return;
        closed = true; stopped = true; polling.shutdownNow();
        try { vm.detach(); } catch (IOException ignored) { }
    }
}
