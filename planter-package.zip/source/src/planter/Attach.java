package planter;
import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;
import com.sun.tools.attach.AgentInitializationException;
import java.nio.file.Path;
public final class Attach {
    public static void main(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("--list")) {
            for (VirtualMachineDescriptor vm : VirtualMachine.list())
                System.out.println(vm.id() + "\t" + vm.displayName());
            return;
        }
        if (args.length < 2 || args.length > 3) {
            System.err.println("Usage: java --add-modules jdk.attach -jar planter-agent.jar <PID> <agent.jar> [radius=8,budget=70,interval=100|stop|gui]");
            System.exit(2);
        }
        VirtualMachine vm = VirtualMachine.attach(args[0]);
        boolean failed = false;
        try {
            String options = args.length == 3 ? args[2] : "";
            var properties = vm.getSystemProperties();
            if (!options.equals("stop") && properties.getProperty("planter.agent.installed") != null
                    && !Agent.VERSION.equals(properties.getProperty("planter.agent.version"))) {
                System.err.println("An older planter agent is already loaded. Restart Minecraft, find its new PID with attach.cmd, then attach this package again.");
                failed = true;
            } else {
                try { vm.loadAgent(Path.of(args[1]).toAbsolutePath().toString(), options); }
                catch (AgentInitializationException failure) {
                    failed = true;
                    String detail = vm.getSystemProperties().getProperty("planter.agent.error");
                    System.err.println("Planter initialization failed" + (detail == null ? "." : ": " + detail));
                    System.err.println("If an older agent was loaded, restart Minecraft and use its new PID. Otherwise, check Minecraft's logs/latest.log or launcher console for the Attach Listener exception.");
                }
            }
        }
        finally { vm.detach(); }
        if (failed) { System.exit(1); return; }
        System.out.println(args.length == 3 && args[2].equals("stop")
            ? "Stop request delivered."
            : args.length == 3 && args[2].equals("gui") ? "Settings window requested."
            : "Agent attached. Press P in Minecraft to toggle; END stops.");
    }
}
