package planter;
import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;
import java.nio.file.Path;
public final class Attach {
    public static void main(String[] args) throws Exception {
        if (args.length == 0 || args[0].equals("--list")) {
            for (VirtualMachineDescriptor vm : VirtualMachine.list())
                System.out.println(vm.id() + "\t" + vm.displayName());
            return;
        }
        if (args.length < 2 || args.length > 3) {
            System.err.println("Usage: java --add-modules jdk.attach -jar planter-agent.jar <PID> <agent.jar> [radius=8,budget=70,interval=100|stop|gui]");
            System.exit(2);
        }
        VirtualMachine vm = VirtualMachine.attach(args[0]);
        try { vm.loadAgent(Path.of(args[1]).toAbsolutePath().toString(), args.length == 3 ? args[2] : ""); }
        finally { vm.detach(); }
        System.out.println(args.length == 3 && args[2].equals("stop")
            ? "Stop request delivered."
            : args.length == 3 && args[2].equals("gui") ? "Settings window requested."
            : "Agent attached. Press P in Minecraft to toggle; END stops.");
    }
}
