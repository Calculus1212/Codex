package planter;

import java.awt.*;
import java.text.ParseException;
import java.util.function.*;
import javax.swing.*;
import javax.swing.border.*;

/** A separate desktop window; only immutable settings cross into the game thread. */
final class SettingsWindow {
    private JDialog frame;
    private SettingsPanel panel;
    private Timer lifecycle;
    private boolean headlessReported;

    void show(Supplier<Agent.Config> read, Consumer<Agent.Config> apply, BooleanSupplier stopped) {
        if (GraphicsEnvironment.isHeadless()) {
            if (!headlessReported) {
                headlessReported = true;
                System.out.println("[Planter] Settings window needs a desktop display; command-line settings remain available.");
            }
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try {
                if (stopped.getAsBoolean()) return;
                if (frame == null || !frame.isDisplayable()) {
                    panel = new SettingsPanel(read, apply, stopped, () -> frame.setVisible(false));
                    JScrollPane scrolling = new JScrollPane(panel,
                        ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
                    scrolling.setBorder(new EmptyBorder(0,0,0,0));
                    scrolling.getVerticalScrollBar().setUnitIncrement(20);
                    JOptionPane options = new JOptionPane(scrolling, JOptionPane.PLAIN_MESSAGE,
                        JOptionPane.DEFAULT_OPTION, null, new Object[0]);
                    frame = options.createDialog(null, "Replanter settings");
                    frame.setModal(false);
                    frame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
                    frame.pack();
                    Rectangle desktop = GraphicsEnvironment.getLocalGraphicsEnvironment().getMaximumWindowBounds();
                    if(frame.getHeight()>desktop.height-40)frame.setSize(frame.getWidth()+18,Math.max(320,desktop.height-40));
                    frame.setMinimumSize(new Dimension(frame.getWidth(),Math.min(480,frame.getHeight())));
                    frame.setLocationByPlatform(true);
                    lifecycle = new Timer(250, e -> { if (stopped.getAsBoolean()) dispose(); });
                    lifecycle.start();
                }
                panel.load(read.get());
                frame.setVisible(true);
                frame.toFront();
            } catch (RuntimeException failure) {
                System.err.println("[Planter] Could not open settings: " + failure);
            }
        });
    }

    void dispose() {
        SwingUtilities.invokeLater(() -> {
            if (lifecycle != null) { lifecycle.stop(); lifecycle = null; }
            if (frame != null) { frame.dispose(); frame = null; panel = null; }
        });
    }

    static final class SettingsPanel extends JPanel {
        final JSpinner delay, requests, range;
        final JCheckBox usePattern = new JCheckBox("Use checked cells (7 × 7 pattern)");
        final JCheckBox[] cells = new JCheckBox[49];
        final JButton selectAll = new JButton("Select all"), clearAll = new JButton("Clear all");
        final JButton applyButton = new JButton("Apply settings");
        final JButton defaultsButton = new JButton("Defaults");
        final JButton hideButton = new JButton("Hide");
        final JLabel message = new JLabel(" ");
        private final Consumer<Agent.Config> apply;
        private final BooleanSupplier stopped;

        SettingsPanel(Supplier<Agent.Config> read, Consumer<Agent.Config> apply,
                      BooleanSupplier stopped, Runnable hide) {
            super(new BorderLayout(0, 12));
            this.apply = apply; this.stopped = stopped;
            setBackground(new Color(246, 248, 251));
            setBorder(new EmptyBorder(16, 20, 14, 20));
            Agent.Config settings = read.get();
            delay = new JSpinner(new SpinnerNumberModel(settings.interval(), 20, 1000, 10));
            requests = new JSpinner(new SpinnerNumberModel(settings.budget() == 0 ? 70 : settings.budget(), 1, 70, 1));
            range = new JSpinner(new SpinnerNumberModel(settings.radius(), 0.0, 8.0, .5));
            range.setEditor(new JSpinner.NumberEditor(range, "0.##"));
            delay.setName("batchDelay"); requests.setName("batchRequests"); range.setName("targetRange");
            delay.getAccessibleContext().setAccessibleName("Batch delay in milliseconds");
            requests.getAccessibleContext().setAccessibleName("Maximum requests per batch");
            range.getAccessibleContext().setAccessibleName("Target range in blocks");

            JPanel heading = new JPanel(new GridLayout(0, 1, 0, 5));
            heading.setOpaque(false);
            JLabel title = new JLabel("Replanter settings");
            title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
            heading.add(title);
            JLabel sub = new JLabel("Changes apply to the running module.");
            sub.setForeground(new Color(80, 93, 110)); heading.add(sub); add(heading, BorderLayout.NORTH);

            JPanel form = new JPanel(new GridBagLayout());
            form.setBackground(Color.WHITE);
            form.setBorder(new CompoundBorder(new LineBorder(new Color(220, 225, 233)), new EmptyBorder(16, 16, 16, 16)));
            row(form, 0, "Delay between batches", "20–1000 milliseconds", delay);
            row(form, 1, "Maximum blocks per batch", "1–70 placement attempts", requests);
            row(form, 2, "Target range", "Greater than 0, up to 8 blocks", range);
            JPanel center = new JPanel(new BorderLayout(0, 12)); center.setOpaque(false);
            center.add(form, BorderLayout.NORTH);
            JPanel pattern = new JPanel(new BorderLayout(4, 4)); pattern.setOpaque(false);
            usePattern.setOpaque(false); pattern.add(usePattern, BorderLayout.NORTH);
            JPanel grid = new JPanel(new GridLayout(7, 7, 2, 2)); grid.setOpaque(false);
            for (int row=0; row<7; row++) for (int col=0; col<7; col++) {
                int index=row*7+col;
                JCheckBox cell = new JCheckBox(index==24 ? "●" : "");
                cell.setName("cell_"+row+"_"+col);
                cell.setHorizontalAlignment(SwingConstants.CENTER);
                cell.setPreferredSize(new Dimension(38, 28)); cell.setMargin(new Insets(0,0,0,0));
                cell.setOpaque(true); cell.setBorderPainted(true);
                cell.setBackground(index==24 ? new Color(255,238,177) : Color.WHITE);
                cell.setBorder(new LineBorder(index==24 ? new Color(185,128,20) : new Color(210,218,230)));
                String description=(index==24 ? "Your position; " : "")+"offset X="+(col-3)+", Z="+(row-3);
                cell.setToolTipText(description);cell.getAccessibleContext().setAccessibleName(description);
                cells[index]=cell;grid.add(cell);
            }
            JPanel compass = new JPanel(new BorderLayout(6, 4));compass.setOpaque(false);
            compass.add(new JLabel("North (−Z)", SwingConstants.CENTER),BorderLayout.NORTH);
            compass.add(new JLabel("W"),BorderLayout.WEST);compass.add(new JLabel("E"),BorderLayout.EAST);
            compass.add(new JLabel("South (+Z) · highlighted center = you", SwingConstants.CENTER),BorderLayout.SOUTH);
            compass.add(grid,BorderLayout.CENTER);pattern.add(compass,BorderLayout.CENTER);
            JPanel selection = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));selection.setOpaque(false);
            selection.add(selectAll);selection.add(clearAll);pattern.add(selection,BorderLayout.SOUTH);
            selectAll.addActionListener(e -> {for(JCheckBox cell:cells)cell.setSelected(true);});
            clearAll.addActionListener(e -> {for(JCheckBox cell:cells)cell.setSelected(false);});
            usePattern.addActionListener(e -> setPatternEnabled());
            center.add(pattern,BorderLayout.CENTER);add(center,BorderLayout.CENTER);

            JPanel footer = new JPanel(new BorderLayout(0, 12)); footer.setOpaque(false);
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));buttons.setOpaque(false);
            buttons.add(applyButton); buttons.add(defaultsButton); buttons.add(hideButton);
            footer.add(buttons, BorderLayout.NORTH);
            JPanel notes = new JPanel(new GridLayout(0, 1, 0, 7)); notes.setOpaque(false);
            notes.add(message);
            JLabel controls = new JLabel("P: toggle in game   •   O: settings   •   End: stop");
            controls.setForeground(new Color(80, 93, 110)); notes.add(controls);
            JLabel reach = new JLabel("The server decides which interactions succeed.");
            reach.setForeground(new Color(80, 93, 110)); notes.add(reach);
            footer.add(notes, BorderLayout.CENTER);add(footer, BorderLayout.SOUTH);
            applyButton.addActionListener(e -> apply());
            defaultsButton.addActionListener(e -> {
                load(new Agent.Config(8, 70, 100, 100));
                feedback("Defaults loaded. Click Apply settings.", false);
            });
            hideButton.addActionListener(e -> hide.run());
            load(settings);
        }

        private static void row(JPanel form, int y, String label, String hint, JSpinner spinner) {
            JPanel text = new JPanel(new GridLayout(0, 1, 0, 4));text.setOpaque(false);
            JLabel heading = new JLabel(label);heading.setFont(heading.getFont().deriveFont(Font.BOLD, 13f));
            JLabel helper = new JLabel(hint);helper.setFont(helper.getFont().deriveFont(11f));helper.setForeground(new Color(93, 107, 125));
            text.add(heading);text.add(helper);
            spinner.setPreferredSize(new Dimension(94, 32));
            GridBagConstraints c = new GridBagConstraints();c.gridx=0;c.gridy=y;c.weightx=1;c.anchor=GridBagConstraints.WEST;c.insets=new Insets(y==0?0:12,0,0,22);
            form.add(text,c);
            c.gridx=1;c.weightx=0;c.insets=new Insets(y==0?0:12,0,0,0);form.add(spinner,c);
            heading.setLabelFor(spinner);
        }

        void load(Agent.Config settings) {
            delay.setValue(settings.interval()); requests.setValue(settings.budget() == 0 ? 70 : settings.budget()); range.setValue(settings.radius());
            usePattern.setSelected(settings.usePattern());
            for(int i=0;i<49;i++)cells[i].setSelected((settings.pattern() & (1L<<i))!=0);
            setPatternEnabled();
            feedback("Ready. Edit values, then click Apply settings.", false);
        }
        private void apply() {
            try {
                if (stopped.getAsBoolean()) throw new IllegalStateException("Agent stopped. Restart Minecraft and attach again.");
                delay.commitEdit(); requests.commitEdit(); range.commitEdit();
                int ms=((Number)delay.getValue()).intValue(), count=((Number)requests.getValue()).intValue();
                double blocks=((Number)range.getValue()).doubleValue();
                if (count < 1 || count > 70) throw new IllegalArgumentException("Requests per batch must be 1 to 70.");
                long mask=0;
                for(int i=0;i<49;i++)if(cells[i].isSelected())mask|=1L<<i;
                apply.accept(new Agent.Config(blocks, count, ms, ms, mask, usePattern.isSelected()));
                feedback("Applied: " + ms + " ms / " + count + " requests / "
                    + (usePattern.isSelected() ? Long.bitCount(mask)+" selected cells." : "full radius scan."), false);
            } catch (ParseException | IllegalArgumentException | IllegalStateException failure) {
                feedback(failure instanceof ParseException ? "Enter valid numbers before applying." : failure.getMessage(), true);
            }
        }
        private void feedback(String text, boolean error) {
            message.setText(text);message.setForeground(error ? new Color(178, 38, 38) : new Color(35, 104, 71));
        }
        private void setPatternEnabled() {
            boolean enabled=usePattern.isSelected();
            for(JCheckBox cell:cells)cell.setEnabled(enabled);
            selectAll.setEnabled(enabled);clearAll.setEnabled(enabled);
        }
    }
}
