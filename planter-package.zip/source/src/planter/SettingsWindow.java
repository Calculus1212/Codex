package planter;

import java.awt.*;
import java.text.ParseException;
import java.util.function.*;
import javax.swing.*;
import javax.swing.border.*;

/** A separate desktop window; only immutable settings cross into the game thread. */
final class SettingsWindow {
    private JFrame frame;
    private SettingsPanel panel;
    private Timer lifecycle;
    private boolean headlessReported;

    void show(Supplier<Agent.Config> read, Consumer<Agent.Config> apply, BooleanSupplier stopped) {
        if (GraphicsEnvironment.isHeadless()) {
            if (!headlessReported) {
                headlessReported = true;
                System.out.println("[Planter] Settings window needs a desktop display; command-line settings remain available.");
            }
            return;
        }
        SwingUtilities.invokeLater(() -> {
            try {
                if (stopped.getAsBoolean()) return;
                if (frame == null || !frame.isDisplayable()) {
                    frame = new JFrame("Top placement settings");
                    frame.setDefaultCloseOperation(WindowConstants.HIDE_ON_CLOSE);
                    panel = new SettingsPanel(read, apply, stopped, () -> frame.setVisible(false));
                    frame.setContentPane(panel);
                    frame.pack();
                    frame.setMinimumSize(frame.getSize());
                    frame.setLocationByPlatform(true);
                    lifecycle = new Timer(250, e -> { if (stopped.getAsBoolean()) dispose(); });
                    lifecycle.start();
                }
                panel.load(read.get());
                frame.setVisible(true);
                frame.toFront();
            } catch (RuntimeException failure) {
                System.err.println("[Planter] Could not open settings: " + failure);
            }
        });
    }

    void dispose() {
        SwingUtilities.invokeLater(() -> {
            if (lifecycle != null) { lifecycle.stop(); lifecycle = null; }
            if (frame != null) { frame.dispose(); frame = null; panel = null; }
        });
    }

    static final class SettingsPanel extends JPanel {
        final JSpinner delay, requests, range;
        final JButton applyButton = new JButton("Apply settings");
        final JButton defaultsButton = new JButton("Defaults");
        final JButton hideButton = new JButton("Hide");
        final JLabel message = new JLabel(" ");
        private final Consumer<Agent.Config> apply;
        private final BooleanSupplier stopped;

        SettingsPanel(Supplier<Agent.Config> read, Consumer<Agent.Config> apply,
                      BooleanSupplier stopped, Runnable hide) {
            super(new BorderLayout(0, 18));
            this.apply = apply; this.stopped = stopped;
            setBackground(new Color(246, 248, 251));
            setBorder(new EmptyBorder(22, 24, 20, 24));
            Agent.Config settings = read.get();
            delay = new JSpinner(new SpinnerNumberModel(settings.interval(), 20, 1000, 10));
            requests = new JSpinner(new SpinnerNumberModel(settings.budget() == 0 ? 70 : settings.budget(), 1, 70, 1));
            range = new JSpinner(new SpinnerNumberModel(settings.radius(), 0.0, 8.0, .5));
            range.setEditor(new JSpinner.NumberEditor(range, "0.##"));
            delay.setName("batchDelay"); requests.setName("batchRequests"); range.setName("targetRange");
            delay.getAccessibleContext().setAccessibleName("Batch delay in milliseconds");
            requests.getAccessibleContext().setAccessibleName("Maximum requests per batch");
            range.getAccessibleContext().setAccessibleName("Target range in blocks");

            JPanel heading = new JPanel(new GridLayout(0, 1, 0, 5));
            heading.setOpaque(false);
            JLabel title = new JLabel("Placement settings");
            title.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 21));
            heading.add(title);
            JLabel sub = new JLabel("Changes apply to the running module.");
            sub.setForeground(new Color(80, 93, 110)); heading.add(sub); add(heading, BorderLayout.NORTH);

            JPanel form = new JPanel(new GridBagLayout());
            form.setBackground(Color.WHITE);
            form.setBorder(new CompoundBorder(new LineBorder(new Color(220, 225, 233)), new EmptyBorder(16, 16, 16, 16)));
            row(form, 0, "Delay between batches", "20–1000 milliseconds", delay);
            row(form, 1, "Maximum requests per batch", "1–70 requests", requests);
            row(form, 2, "Target range", "Greater than 0, up to 8 blocks", range);
            add(form, BorderLayout.CENTER);

            JPanel footer = new JPanel(new BorderLayout(0, 12)); footer.setOpaque(false);
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));buttons.setOpaque(false);
            buttons.add(applyButton); buttons.add(defaultsButton); buttons.add(hideButton);
            footer.add(buttons, BorderLayout.NORTH);
            JPanel notes = new JPanel(new GridLayout(0, 1, 0, 7)); notes.setOpaque(false);
            notes.add(message);
            JLabel controls = new JLabel("P: toggle in game   •   O: settings   •   End: stop");
            controls.setForeground(new Color(80, 93, 110)); notes.add(controls);
            JLabel reach = new JLabel("The server decides which interactions succeed.");
            reach.setForeground(new Color(80, 93, 110)); notes.add(reach);
            footer.add(notes, BorderLayout.CENTER);add(footer, BorderLayout.SOUTH);
            applyButton.addActionListener(e -> apply());
            defaultsButton.addActionListener(e -> {
                load(new Agent.Config(8, 70, 100, 100));
                feedback("Defaults loaded. Click Apply settings.", false);
            });
            hideButton.addActionListener(e -> hide.run());
            load(settings);
        }

        private static void row(JPanel form, int y, String label, String hint, JSpinner spinner) {
            JPanel text = new JPanel(new GridLayout(0, 1, 0, 4));text.setOpaque(false);
            JLabel heading = new JLabel(label);heading.setFont(heading.getFont().deriveFont(Font.BOLD, 13f));
            JLabel helper = new JLabel(hint);helper.setFont(helper.getFont().deriveFont(11f));helper.setForeground(new Color(93, 107, 125));
            text.add(heading);text.add(helper);
            spinner.setPreferredSize(new Dimension(94, 32));
            GridBagConstraints c = new GridBagConstraints();c.gridx=0;c.gridy=y;c.weightx=1;c.anchor=GridBagConstraints.WEST;c.insets=new Insets(y==0?0:18,0,0,22);
            form.add(text,c);
            c.gridx=1;c.weightx=0;c.insets=new Insets(y==0?0:18,0,0,0);form.add(spinner,c);
            heading.setLabelFor(spinner);
        }

        void load(Agent.Config settings) {
            delay.setValue(settings.interval()); requests.setValue(settings.budget() == 0 ? 70 : settings.budget()); range.setValue(settings.radius());
            feedback("Ready. Edit values, then click Apply settings.", false);
        }
        private void apply() {
            try {
                if (stopped.getAsBoolean()) throw new IllegalStateException("Agent stopped. Restart Minecraft and attach again.");
                delay.commitEdit(); requests.commitEdit(); range.commitEdit();
                int ms=((Number)delay.getValue()).intValue(), count=((Number)requests.getValue()).intValue();
                double blocks=((Number)range.getValue()).doubleValue();
                if (count < 1 || count > 70) throw new IllegalArgumentException("Requests per batch must be 1 to 70.");
                apply.accept(new Agent.Config(blocks, count, ms, ms));
                feedback("Applied: " + ms + " ms / " + count + " requests / " + blocks + " blocks.", false);
            } catch (ParseException | IllegalArgumentException | IllegalStateException failure) {
                feedback(failure instanceof ParseException ? "Enter valid numbers before applying." : failure.getMessage(), true);
            }
        }
        private void feedback(String text, boolean error) {
            message.setText(text);message.setForeground(error ? new Color(178, 38, 38) : new Color(35, 104, 71));
        }
    }
}
