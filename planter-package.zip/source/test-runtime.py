#!/usr/bin/env python3
"""Attach to actual JVMs; game, inventory and server behavior are mocked."""
import pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
jar=root/'dist/planter-agent.jar'
def attach(pid,options=None):
 command=['java','--add-modules','jdk.attach','-jar',str(jar),pid,str(jar)]
 if options:command.append(options)
 subprocess.run(command,check=True,timeout=15)
def run(limited=False):
 p=subprocess.Popen(['java','-cp',str(root/'build/test-classes'),'PlantFixture']+(['limited'] if limited else []),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  line=p.stdout.readline().strip();print(line,flush=True)
  if not line.startswith('READY '):raise RuntimeError('fixture failed to start')
  pid=line.split()[1];attach(pid,'radius=5,budget=3,interval=100' if limited else None)
  passed=False
  for line in p.stdout:
   print(line,end='',flush=True)
   if line.strip()=='WAIT_STOP':attach(pid,'stop')
   if line.startswith('PASS '):passed=True
  p.wait(timeout=10)
  if p.returncode!=0 or not passed:raise RuntimeError('plant fixture failed')
 finally:
  if p.poll() is None:p.kill();p.wait()
run()
run(True)
