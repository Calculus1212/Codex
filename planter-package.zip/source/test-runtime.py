#!/usr/bin/env python3
"""Attach to actual JVMs; game, inventory and server behavior are mocked."""
import pathlib,subprocess
root=pathlib.Path(__file__).resolve().parent
jar=root/'dist/planter-agent.jar'
def attach(pid,options=None):
 command=['java','--add-modules','jdk.attach','-jar',str(jar),pid,str(jar)]
 if options:command.append(options)
 subprocess.run(command,check=True,timeout=15)
def run(limited=False):
 p=subprocess.Popen(['java','-cp',str(root/'build/test-classes'),'PlantFixture']+(['limited'] if limited else []),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  line=p.stdout.readline().strip();print(line,flush=True)
  if not line.startswith('READY '):raise RuntimeError('fixture failed to start')
  pid=line.split()[1];attach(pid,'radius=8,budget=3,interval=100,pattern=off' if limited else 'radius=8,budget=70,interval=100,pattern=off')
  passed=False
  for line in p.stdout:
   print(line,end='',flush=True)
   if line.strip()=='WAIT_STOP':attach(pid,'stop')
   if line.startswith('PASS '):passed=True
  p.wait(timeout=10)
  if p.returncode!=0 or not passed:raise RuntimeError('plant fixture failed')
 finally:
  if p.poll() is None:p.kill();p.wait()
run()
run(True)

def live_settings():
 p=subprocess.Popen(['java','-Djava.awt.headless=true','-cp',str(root/'build/test-classes')+':'+str(jar),'planter.LiveSettingsFixture'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 try:
  line=p.stdout.readline().strip();print(line,flush=True)
  if not line.startswith('READY '):raise RuntimeError('settings fixture failed to start')
  pid=line.split()[1];attach(pid,'gui')
  passed=False
  for line in p.stdout:
   print(line,end='',flush=True)
   if line.strip()=='WAIT_GUI':attach(pid,'gui');p.stdin.write('continue\n');p.stdin.flush()
   if line.startswith('PASS '):passed=True
  p.wait(timeout=10)
  if p.returncode!=0 or not passed:raise RuntimeError('settings fixture failed')
 finally:
  if p.poll() is None:p.kill();p.wait()
live_settings()

def attach_failures():
 for older in [False,True]:
  p=subprocess.Popen(['java','-cp',str(root/'build/test-classes'),'planter.AttachFailureFixture']+(['older'] if older else []),stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  try:
   line=p.stdout.readline().strip()
   if not line.startswith('READY '):raise RuntimeError('failure fixture failed to start')
   result=subprocess.run(['java','--add-modules','jdk.attach','-jar',str(jar),line.split()[1],str(jar),'gui'],capture_output=True,text=True,timeout=15)
   expected='An older planter agent is already loaded' if older else 'No running intermediary Minecraft client found'
   if result.returncode!=1 or expected not in result.stderr:raise RuntimeError('Missing useful diagnosis: '+result.stderr)
   if 'Exception in thread "main"' in result.stderr:raise RuntimeError('Launcher hid cause behind generic exception')
   print('PASS '+('old agent upgrade guard' if older else 'target-side initialization error reaches CMD'),flush=True)
  finally:
   if p.poll() is None:p.kill();p.wait()
attach_failures()
