#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
./build.sh
mkdir -p build/test-classes
mapfile -t sources < <(find test -name '*.java' -type f)
java com.sun.tools.javac.Main -source 21 -target 21 -cp build/classes -d build/test-classes "${sources[@]}"
python3 test-runtime.py
