package net.minecraft;
public class class_1297 {
 public class_243 eyes=new class_243(.5,2.5,.5);
 public class_243 method_33571(){return eyes;}
}
