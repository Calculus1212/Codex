package net.minecraft;
public class class_1297 {
 public double feet=1;
 public double method_23318(){return feet;}
 public class_243 eyes=new class_243(.5,2.5,.5);
 public class_243 method_33571(){return eyes;}
}
