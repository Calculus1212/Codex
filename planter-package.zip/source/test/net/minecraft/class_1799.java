package net.minecraft;
public class class_1799 {
 public class_1792 item;public int count;
 public class_1799(String id,int n){item=new class_1792(id);count=n;}
 public class_1792 method_7909(){return item;}
 public int method_7947(){return count;}
 public boolean method_7960(){return count<=0;}
}
