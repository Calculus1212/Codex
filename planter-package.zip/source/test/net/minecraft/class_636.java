package net.minecraft;
import java.util.*;
public class class_636 {
 public final List<class_2596> packets=new ArrayList<>();
 public final List<Long> sentAt=new ArrayList<>();
 public int synced;private int sequence;public boolean plantImmediately;
 private void method_2911(){synced++;}
 private void method_41931(class_638 world,class_7204 creator){
  class_2596 packet=creator.predict(++sequence);packets.add(packet);sentAt.add(System.nanoTime());
  if(plantImmediately){
   class_2885 p=(class_2885)packet;class_2338 soil=p.hit.pos;
   world.blocks.put(new class_2338(soil.x(),soil.y()+1,soil.z()),new class_2680(false,0,new class_2248("erazion:experience_roots"),false));
   class_310.INSTANCE.field_1724.held.count--;
  }
 }
}
