package net.minecraft;
public final class class_7923 {
 public static final class_7922 field_41175=new class_7922(),field_41178=new class_7922();
}
