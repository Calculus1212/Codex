package net.minecraft;
public class class_243 {
 public double field_1352,field_1351,field_1350;
 public class_243(double x,double y,double z){field_1352=x;field_1351=y;field_1350=z;}
}
