package net.minecraft;
public interface class_2378 {class_2960 method_10221(Object value);}
