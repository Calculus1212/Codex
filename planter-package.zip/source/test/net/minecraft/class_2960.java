package net.minecraft;
public record class_2960(String value){public String toString(){return value;}}
