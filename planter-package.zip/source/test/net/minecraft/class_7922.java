package net.minecraft;
public class class_7922 implements class_2378 {
 public class_2960 method_10221(Object value){
  String id=value instanceof class_2248 b?b.name:((class_1792)value).id;
  return new class_2960(id.contains(":")?id:"minecraft:"+id);
 }
}
