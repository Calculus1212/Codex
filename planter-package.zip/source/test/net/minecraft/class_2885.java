package net.minecraft;
public class class_2885 implements class_2596 {
 public final class_1268 hand;public final class_3965 hit;public final int sequence;
 public class_2885(class_1268 hand,class_3965 hit,int sequence){this.hand=hand;this.hit=hit;this.sequence=sequence;}
}
