package net.minecraft;
public class class_3965 {
 public final class_243 hit;public final class_2350 side;public final class_2338 pos;public final boolean inside;
 public class_3965(class_243 hit,class_2350 side,class_2338 pos,boolean inside){this.hit=hit;this.side=side;this.pos=pos;this.inside=inside;}
}
