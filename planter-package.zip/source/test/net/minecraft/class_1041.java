package net.minecraft; public class class_1041 { public long method_4490(){return 1;} }
