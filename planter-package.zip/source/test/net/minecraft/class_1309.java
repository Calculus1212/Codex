package net.minecraft;
public class class_1309 extends class_1297 {
 public class_1799 held=new class_1799("erazion:experience_seeds",64);
 public class_1799 method_6047(){return held;}
}
