package net.minecraft;
public final class class_265 {
 private final double top;
 public class_265(double top){this.top=top;}
 public boolean method_1110(){return top<=0;}
 public double method_1105(class_2350.class_2351 axis){return top;}
}
