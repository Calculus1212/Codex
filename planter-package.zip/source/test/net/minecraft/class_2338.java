package net.minecraft; public record class_2338(int x,int y,int z) {}
