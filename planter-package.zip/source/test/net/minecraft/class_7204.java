package net.minecraft; public interface class_7204 {class_2596 predict(int sequence);}
