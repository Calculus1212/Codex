package net.minecraft; public enum class_2350 { UP; public static class_2350 method_10142(double x,double y,double z){return UP;} }
