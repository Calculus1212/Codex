package net.minecraft; public enum class_2350 { UP; public enum class_2351 {X,Y,Z} }
