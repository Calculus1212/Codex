package net.minecraft; public interface class_2596 {}
