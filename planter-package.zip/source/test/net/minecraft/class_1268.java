package net.minecraft;
public enum class_1268 {MAIN_HAND,OFF_HAND}
