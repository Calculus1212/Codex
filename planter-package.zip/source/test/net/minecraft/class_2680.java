package net.minecraft;
public class class_2680 {
 final boolean air; final float hardness; public final class_2248 block; public final boolean lit;
 public class_2680(boolean air,float hardness){this(air,hardness,new class_2248(air?"air":"stone"),false);}
 public class_2680(boolean air,float hardness,class_2248 block,boolean lit){this.air=air;this.hardness=hardness;this.block=block;this.lit=lit;}
 public double top(){return air||block.name.equals("water")||block.name.equals("tall_grass")?0:block.name.equals("farmland")?.9375:block.name.equals("slab")?.5:1;}
 public class_265 method_26220(class_1922 w,class_2338 p){return new class_265(top());}
 public boolean method_26215(){return air;}
 public float method_26214(class_1922 w,class_2338 p){return hardness;}
 public class_2248 method_26204(){return block;}
}
