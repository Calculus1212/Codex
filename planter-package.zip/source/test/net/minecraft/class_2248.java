package net.minecraft;
public class class_2248 { public final String name; public class_2248(String name){this.name=name;} }
