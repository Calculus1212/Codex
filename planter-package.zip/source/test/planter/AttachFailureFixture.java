package planter;

/** Keep a non-Minecraft JVM alive to verify diagnostics and the old-version guard. */
public final class AttachFailureFixture {
    public static void main(String[] args) throws Exception {
        if (args.length > 0) System.setProperty("planter.agent.installed", "true");
        System.out.println("READY " + ProcessHandle.current().pid()); System.out.flush();
        System.in.read();
    }
}
