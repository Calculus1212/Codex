package planter;

import java.awt.*;
import java.awt.event.*;
import java.nio.file.*;
import java.util.concurrent.atomic.*;
import javax.imageio.ImageIO;
import javax.swing.*;

/** Optional desktop smoke test: run with a real display or Xvfb. */
public final class WindowFixture {
    public static void main(String[] args) throws Exception {
        AtomicReference<Agent.Config> settings=new AtomicReference<>(new Agent.Config(8,70,100,100));
        AtomicBoolean stopped=new AtomicBoolean();
        SettingsWindow window=new SettingsWindow();
        window.show(settings::get,settings::set,stopped::get);
        SwingUtilities.invokeAndWait(() -> {});
        JFrame[] frame=new JFrame[1];
        Point[] click=new Point[1];
        SwingUtilities.invokeAndWait(() -> {
            for(Frame f:Frame.getFrames()) if(f instanceof JFrame j && j.isVisible())frame[0]=j;
            if(frame[0]==null)throw new AssertionError("No settings window");
            SettingsWindow.SettingsPanel p=(SettingsWindow.SettingsPanel)frame[0].getContentPane();
            p.delay.setValue(250);p.requests.setValue(35);p.range.setValue(6.0);
            Point pos=p.applyButton.getLocationOnScreen();
            click[0]=new Point(pos.x+p.applyButton.getWidth()/2,pos.y+p.applyButton.getHeight()/2);
        });
        Robot robot=new Robot();robot.setAutoDelay(80);
        robot.mouseMove(click[0].x,click[0].y);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();
        if(!settings.get().equals(new Agent.Config(6,35,250,250)))throw new AssertionError("Actual Apply click failed");
        if(args.length>0) ImageIO.write(robot.createScreenCapture(frame[0].getBounds()),"png",Path.of(args[0]).toFile());
        SwingUtilities.invokeAndWait(() -> frame[0].dispatchEvent(new WindowEvent(frame[0],WindowEvent.WINDOW_CLOSING)));
        if(frame[0].isVisible() || !frame[0].isDisplayable())throw new AssertionError("Close must hide");
        window.show(settings::get,settings::set,stopped::get);SwingUtilities.invokeAndWait(() -> {});
        if(!frame[0].isVisible())throw new AssertionError("Reopen failed");
        stopped.set(true);window.dispose();SwingUtilities.invokeAndWait(() -> {});
        if(frame[0].isDisplayable())throw new AssertionError("Stop must dispose");
        System.out.println("PASS desktop window, actual Apply click, hide, reopen and dispose");
    }
}
