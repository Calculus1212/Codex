package planter;

import java.awt.*;
import java.awt.event.*;
import java.nio.file.*;
import java.util.concurrent.atomic.*;
import javax.imageio.ImageIO;
import javax.swing.*;

/** Optional desktop smoke test: run with a real display or Xvfb. */
public final class WindowFixture {
    static SettingsWindow.SettingsPanel panel(Container root) {
        if(root instanceof SettingsWindow.SettingsPanel p)return p;
        for(Component child:root.getComponents())if(child instanceof Container c){var p=panel(c);if(p!=null)return p;}
        return null;
    }
    public static void main(String[] args) throws Exception {
        AtomicReference<Agent.Config> settings=new AtomicReference<>(new Agent.Config(8,70,100,100));
        AtomicBoolean stopped=new AtomicBoolean();
        SettingsWindow window=new SettingsWindow();
        window.show(settings::get,settings::set,stopped::get);
        SwingUtilities.invokeAndWait(() -> {});
        JDialog[] frame=new JDialog[1];
        Point[] click=new Point[1];
        Point[] cellClick=new Point[1];
        long mask=(1L<<24)|(1L<<17)|(1L<<31)|(1L<<23)|(1L<<25);
        SwingUtilities.invokeAndWait(() -> {
            for(Window f:Window.getWindows()) if(f instanceof JDialog j && j.isVisible())frame[0]=j;
            if(frame[0]==null)throw new AssertionError("No settings window");
            SettingsWindow.SettingsPanel p=panel(frame[0]);
            p.delay.setValue(250);p.requests.setValue(35);p.range.setValue(6.0);
            p.clearAll.doClick(0);
            for(int i=0;i<49;i++)p.cells[i].setSelected((mask&(1L<<i))!=0);
            p.cells[6].scrollRectToVisible(new Rectangle(0,0,p.cells[6].getWidth(),p.cells[6].getHeight()));
            Point cell=p.cells[6].getLocationOnScreen();cellClick[0]=new Point(cell.x+12,cell.y+p.cells[6].getHeight()/2);
            Point pos=p.applyButton.getLocationOnScreen();
            click[0]=new Point(pos.x+p.applyButton.getWidth()/2,pos.y+p.applyButton.getHeight()/2);
        });
        Robot robot=new Robot();robot.setAutoDelay(80);
        robot.mouseMove(cellClick[0].x,cellClick[0].y);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();
        SwingUtilities.invokeAndWait(() -> {
            var p=panel(frame[0]);
            p.applyButton.scrollRectToVisible(new Rectangle(0,0,p.applyButton.getWidth(),p.applyButton.getHeight()));
            Point pos=p.applyButton.getLocationOnScreen();click[0]=new Point(pos.x+p.applyButton.getWidth()/2,pos.y+p.applyButton.getHeight()/2);
        });
        robot.mouseMove(click[0].x,click[0].y);
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.waitForIdle();
        if(!settings.get().equals(new Agent.Config(6,35,250,250,mask|(1L<<6),true)))throw new AssertionError("Actual grid/Apply click failed");
        if(args.length>0) ImageIO.write(robot.createScreenCapture(frame[0].getBounds()),"png",Path.of(args[0]).toFile());
        SwingUtilities.invokeAndWait(() -> frame[0].dispatchEvent(new WindowEvent(frame[0],WindowEvent.WINDOW_CLOSING)));
        if(frame[0].isVisible() || !frame[0].isDisplayable())throw new AssertionError("Close must hide");
        window.show(settings::get,settings::set,stopped::get);SwingUtilities.invokeAndWait(() -> {});
        if(!frame[0].isVisible())throw new AssertionError("Reopen failed");
        if(!panel(frame[0]).cells[6].isSelected()||panel(frame[0]).cells[0].isSelected())throw new AssertionError("Reopened grid did not retain mask");
        stopped.set(true);window.dispose();SwingUtilities.invokeAndWait(() -> {});
        if(frame[0].isDisplayable())throw new AssertionError("Stop must dispose");
        System.out.println("PASS desktop window, actual Apply click, hide, reopen and dispose");
    }
}
