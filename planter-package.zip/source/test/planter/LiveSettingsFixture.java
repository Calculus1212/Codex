package planter;

import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import javax.swing.*;
import java.util.*;
import java.io.*;

/** Real JVM attachment and Swing Apply actions against game stubs. */
public final class LiveSettingsFixture {
    static final class_310 mc = class_310.INSTANCE;
    static int checks;
    static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
        checks++;
    }
    static void cycle() throws Exception {
        long deadline = System.nanoTime() + 3_000_000_000L;
        while (mc.queue.isEmpty()) {
            if (System.nanoTime() > deadline) throw new AssertionError("No client task");
            Thread.sleep(1);
        }
        mc.queue.remove().run();
    }
    static Set<class_2338> drain() {
        Set<class_2338> result = new HashSet<>();
        for (class_2596 packet : mc.field_1761.packets)
            check(result.add(((class_2885)packet).hit.pos), "unique target in batch");
        mc.field_1761.packets.clear(); mc.field_1761.sentAt.clear();
        return result;
    }
    public static void main(String[] args) throws Exception {
        mc.field_1724.feet = 1; mc.field_1724.eyes = new class_243(.5,1,.5);
        mc.field_1724.held = new class_1799("minecraft:stone",64);
        for (int x=-8; x<=8; x++) for(int z=-8; z<=8; z++)
            mc.field_1687.blocks.put(new class_2338(x,0,z),new class_2680(false,0));
        System.out.println("READY " + ProcessHandle.current().pid()); System.out.flush();
        while (!"true".equals(System.getProperty("planter.agent.installed"))) cycle();
        cycle(); check(drain().isEmpty(), "starts disabled");
        SettingsWindow.SettingsPanel[] panel = new SettingsWindow.SettingsPanel[1];
        SwingUtilities.invokeAndWait(() -> panel[0] = new SettingsWindow.SettingsPanel(
            Agent::currentSettings, Agent::updateSettings, Agent::isStopped, () -> {}));
        check(Agent.currentSettings().equals(new Agent.Config(8,70,100,100)), "defaults retained");
        GLFW.p=true; cycle(); GLFW.p=false;
        Set<class_2338> first=drain(); check(first.size()==70,"original budget");
        SwingUtilities.invokeAndWait(() -> {
            panel[0].requests.setValue(3); panel[0].delay.setValue(300); panel[0].applyButton.doClick(0);
        });
        cycle(); Set<class_2338> second=drain();
        check(second.size()==3 && Collections.disjoint(first,second),"live budget/delay preserve cursor");
        long started=System.nanoTime(); cycle();
        check(System.nanoTime()-started>=270_000_000L,"live 300ms scheduler delay");
        Set<class_2338> third=drain();
        check(third.size()==3 && Collections.disjoint(first,third) && Collections.disjoint(second,third),"further continuation");
        SwingUtilities.invokeAndWait(() -> {
            panel[0].range.setValue(2.0); panel[0].delay.setValue(20); panel[0].applyButton.doClick(0);
        });
        cycle(); Set<class_2338> changed=drain();
        check(changed.size()==3 && changed.contains(new class_2338(0,0,0)),"range change restarts nearest");
        for(class_2338 p:changed)check(p.x()*p.x()+p.z()*p.z()<=4,"new radius honored");
        started=System.nanoTime(); cycle();
        long elapsed=System.nanoTime()-started;
        check(elapsed>=15_000_000L && elapsed<200_000_000L,"live 20ms scheduler delay"); drain();
        Agent.Config before=Agent.currentSettings();
        SwingUtilities.invokeAndWait(() -> {panel[0].range.setValue(0.0);panel[0].applyButton.doClick(0);});
        check(before.equals(Agent.currentSettings()),"invalid range never replaces live config");
        SwingUtilities.invokeAndWait(() -> {
            ((JSpinner.DefaultEditor)panel[0].delay.getEditor()).getTextField().setText("bad");
            panel[0].applyButton.doClick(0);
        });
        check(before.equals(Agent.currentSettings()),"malformed input never applies");
        SwingUtilities.invokeAndWait(() -> panel[0].defaultsButton.doClick(0));
        check(before.equals(Agent.currentSettings()),"Defaults waits for Apply");
        SwingUtilities.invokeAndWait(() -> panel[0].applyButton.doClick(0));
        check(Agent.currentSettings().equals(new Agent.Config(8,70,100,100)),"Defaults applies all three settings");
        System.out.println("WAIT_GUI"); System.out.flush();
        new BufferedReader(new InputStreamReader(System.in)).readLine();
        check(Agent.currentSettings().equals(new Agent.Config(8,70,100,100)),"reopening does not reinstall or reset settings");
        GLFW.end=true; cycle(); check(Agent.isStopped(),"End stops updated scheduler");
        boolean rejected=false;
        try { Agent.updateSettings(new Agent.Config(8,70,100,100)); }
        catch(IllegalStateException expected){rejected=true;}
        check(rejected,"stopped agent rejects live updates");
        System.out.println("PASS " + checks + " live GUI settings and scheduler checks");
    }
}
