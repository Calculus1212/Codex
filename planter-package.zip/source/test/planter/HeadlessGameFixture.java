package planter;

import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** A separate game JVM forced headless, while the controller JVM has a desktop. */
public final class HeadlessGameFixture {
    public static void main(String[] args) throws Exception {
        class_310 mc = class_310.INSTANCE;
        mc.field_1724.feet = 1; mc.field_1724.eyes = new class_243(.5,1,.5);
        mc.field_1724.held = new class_1799("erazion:experience_seeds",64);
        for(int x=-3;x<=3;x++) for(int z=-3;z<=3;z++)
            mc.field_1687.blocks.put(new class_2338(x,0,z),new class_2680(false,0));
        ConcurrentLinkedQueue<String> commands = new ConcurrentLinkedQueue<>();
        Thread input = new Thread(() -> {
            try { BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
                for(String line;(line=reader.readLine())!=null;) commands.add(line);
            } catch(IOException failure){throw new RuntimeException(failure);}
        });
        input.setDaemon(true);input.start();
        System.out.println("READY " + ProcessHandle.current().pid());System.out.flush();
        long deadline=System.nanoTime()+45_000_000_000L;
        boolean verified=false, collecting=false;
        Set<class_2338> requests = new HashSet<>();
        while(System.nanoTime()<deadline) {
            String command=commands.poll();
            if("verify".equals(command)) {
                long mask=(1L<<24)|(1L<<17)|(1L<<23)|(1L<<6);
                if(!Agent.currentSettings().equals(new Agent.Config(6,3,250,250,mask,true)))
                    throw new AssertionError("External Apply did not update headless game");
                if(!"external".equals(System.getProperty("planter.agent.gui.mode")))
                    throw new AssertionError("Headless fallback was not detected");
                GLFW.p=true;collecting=true;
            }
            if("stop".equals(command)) GLFW.end=true;
            Runnable task=mc.queue.poll();
            if(task!=null) {
                task.run();GLFW.p=false;
                if(collecting) {
                    if(mc.field_1761.packets.size()>3)throw new AssertionError("External request limit ignored");
                    for(class_2596 packet:mc.field_1761.packets) {
                        if(!requests.add(((class_2885)packet).hit.pos))throw new AssertionError("Sweep repeated before selected cells completed");
                    }
                    mc.field_1761.packets.clear();
                    if(requests.size()==4) {
                        Set<class_2338> expected=Set.of(new class_2338(0,0,0),new class_2338(0,0,-1),new class_2338(-1,0,0),new class_2338(3,0,-3));
                        if(!requests.equals(expected))throw new AssertionError("External checkbox pattern ignored");
                        verified=true;collecting=false;
                        System.out.println("PASS external Apply updates headless game and selected pattern packets");System.out.flush();
                    }
                }
                if(Boolean.getBoolean("planter.agent.stop")) {
                    if(!verified)throw new AssertionError("Stopped before external Apply test");
                    System.out.println("PASS external controller observes End stop");System.out.flush();
                    // Keep process alive briefly so the controller can observe the published stop.
                    Thread.sleep(1500);return;
                }
            } else Thread.sleep(1);
        }
        throw new AssertionError("Headless game fixture timed out");
    }
}
