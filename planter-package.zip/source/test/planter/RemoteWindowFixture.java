package planter;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

/** Exercises the exact Attach.main GUI route against a different, headless JVM. */
public final class RemoteWindowFixture {
    static JDialog visible() {
        for(Window window:Window.getWindows())if(window instanceof JDialog dialog&&dialog.isVisible())return dialog;
        return null;
    }
    public static void main(String[] args) throws Exception {
        Attach.main(new String[]{args[0],args[1],"gui"});
        SwingUtilities.invokeAndWait(() -> {});
        JDialog[] dialog=new JDialog[1];
        SwingUtilities.invokeAndWait(() -> {
            dialog[0]=visible();if(dialog[0]==null)throw new AssertionError("External settings did not open");
            var panel=WindowFixture.panel(dialog[0]);
            panel.delay.setValue(250);panel.requests.setValue(3);panel.range.setValue(6.0);
            panel.clearAll.doClick(0);
            for(int index:new int[]{24,17,23,6})panel.cells[index].setSelected(true);
            panel.applyButton.doClick(0);
            if(!panel.message.getText().startsWith("Applied:"))throw new AssertionError(panel.message.getText());
        });
        System.out.println("APPLIED");System.out.flush();
        BufferedReader reader=new BufferedReader(new InputStreamReader(System.in));
        reader.readLine();
        // Close and reopen from CMD without reinstalling or losing the applied pattern.
        SwingUtilities.invokeAndWait(() -> dialog[0].dispatchEvent(new WindowEvent(dialog[0],WindowEvent.WINDOW_CLOSING)));
        Attach.main(new String[]{args[0],args[1],"gui"});
        SwingUtilities.invokeAndWait(() -> {});
        SwingUtilities.invokeAndWait(() -> {
            dialog[0]=visible();if(dialog[0]==null)throw new AssertionError("External reopen failed");
            var panel=WindowFixture.panel(dialog[0]);
            if(!panel.delay.getValue().equals(250)||!panel.requests.getValue().equals(3)
                ||!panel.range.getValue().equals(6.0)||!panel.cells[6].isSelected()||panel.cells[0].isSelected())
                throw new AssertionError("External reopen did not preserve game settings");
        });
        System.out.println("REOPENED");System.out.flush();
        reader.readLine();
        long deadline=System.nanoTime()+5_000_000_000L;
        while(System.nanoTime()<deadline) {
            SwingUtilities.invokeAndWait(() -> {});
            if(!dialog[0].isDisplayable()) {
                System.out.println("PASS external GUI open, Apply, retained settings, reopen and End disposal");return;
            }
            Thread.sleep(30);
        }
        throw new AssertionError("External window did not close when game stopped");
    }
}
