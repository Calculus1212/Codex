package planter;

import java.util.*;
import javax.swing.*;
import net.minecraft.*;
import org.lwjgl.glfw.GLFW;

/** Selected cells must be the only positions receiving packets, across complete sweeps. */
public final class PatternFixture {
    static final class_310 mc=class_310.INSTANCE;
    static int checks;
    static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);checks++;}
    static Set<class_2338> drain(){
        Set<class_2338> out=new HashSet<>();
        for(class_2596 packet:mc.field_1761.packets){
            class_2885 p=(class_2885)packet;
            check(out.add(p.hit.pos),"no duplicate positions within batch");
            check(p.hit.pos.y()==(int)Math.floor(Math.nextDown(mc.field_1724.feet)),"feet support layer retained");
            check(p.hand==class_1268.MAIN_HAND&&p.hit.side==class_2350.UP,"block-use top-face packets retained");
        }
        mc.field_1761.packets.clear();return out;
    }
    public static void main(String[] args)throws Exception{
        mc.field_1724.feet=1;mc.field_1724.eyes=new class_243(.5,1,.5);
        mc.field_1724.held=new class_1799("erazion:experience_seeds",64);
        for(int x=-12;x<=12;x++)for(int z=-12;z<=12;z++)mc.field_1687.blocks.put(new class_2338(x,0,z),new class_2680(false,0));
        Agent.Hooks hooks=new Agent.Hooks(PatternFixture.class.getClassLoader(),new Agent.Config(8,70,20,20));
        hooks.tick(mc);GLFW.p=true;hooks.tick(mc);GLFW.p=false;
        Set<class_2338> all=drain();check(all.size()==49,"default pattern sends exactly 49 targets, no radius extras");
        check(all.contains(new class_2338(-3,0,-3))&&all.contains(new class_2338(3,0,3)),"all grid corners included");
        SettingsWindow.SettingsPanel[] panel=new SettingsWindow.SettingsPanel[1];
        SwingUtilities.invokeAndWait(()->panel[0]=new SettingsWindow.SettingsPanel(()->hooks.config,c->hooks.config=c,()->false,()->{}));
        int[] selected={0,6,24,28,48};Set<class_2338> expected=Set.of(new class_2338(-3,0,-3),new class_2338(3,0,-3),new class_2338(0,0,0),new class_2338(-3,0,1),new class_2338(3,0,3));
        SwingUtilities.invokeAndWait(()->{
            panel[0].clearAll.doClick(0);for(int i:selected)panel[0].cells[i].setSelected(true);
            panel[0].requests.setValue(2);panel[0].delay.setValue(20);panel[0].applyButton.doClick(0);
        });
        hooks.tick(mc);Set<class_2338> first=drain();
        check(first.size()==2&&first.contains(new class_2338(0,0,0)),"pattern edit resets nearest and respects budget");
        Thread.sleep(22);hooks.tick(mc);Set<class_2338> second=drain();
        check(second.size()==2&&Collections.disjoint(first,second),"next batch continues selected cells");
        SwingUtilities.invokeAndWait(()->{panel[0].requests.setValue(1);panel[0].delay.setValue(30);panel[0].applyButton.doClick(0);});
        Thread.sleep(32);hooks.tick(mc);Set<class_2338> last=drain();
        Set<class_2338> visited=new HashSet<>(first);visited.addAll(second);visited.addAll(last);
        check(last.size()==1&&Collections.disjoint(first,last)&&Collections.disjoint(second,last),"budget/delay changes preserve pattern progress");
        check(visited.equals(expected),"only selected cells visited; north, east and center coordinates correct");
        Thread.sleep(32);hooks.tick(mc);check(drain().equals(Set.of(new class_2338(0,0,0))),"restart nearest only after completing whole pattern");
        SwingUtilities.invokeAndWait(()->{panel[0].clearAll.doClick(0);panel[0].cells[0].setSelected(true);panel[0].cells[6].setSelected(true);panel[0].applyButton.doClick(0);});
        hooks.tick(mc);Set<class_2338> beforePause=drain();
        mc.field_1724.held.count=0;hooks.tick(mc);check(drain().isEmpty(),"empty hand sends nothing");
        mc.field_1724.held.count=64;mc.field_1724.eyes.field_1352=.6;hooks.tick(mc);
        check(Collections.disjoint(beforePause,drain())&&hooks.sweep==null,"pause and fractional movement continue to remaining selected corner");
        mc.field_1724.eyes=new class_243(-.5,1,-.5);Thread.sleep(32);hooks.tick(mc);
        check(drain().stream().allMatch(p->p.z()==-4&&(p.x()==-4||p.x()==2)),"grid follows player across negative-coordinate blocks");
        SwingUtilities.invokeAndWait(()->{panel[0].clearAll.doClick(0);panel[0].applyButton.doClick(0);});
        hooks.tick(mc);check(drain().isEmpty(),"zero checked cells sends no requests");
        SwingUtilities.invokeAndWait(()->{panel[0].cells[24].setSelected(true);panel[0].applyButton.doClick(0);});
        hooks.tick(mc);check(drain().equals(Set.of(new class_2338(-1,0,-1))),"center checkbox selectable independently");
        mc.field_1687.blocks.put(new class_2338(-1,1,-1),new class_2680(false,0));Thread.sleep(32);hooks.tick(mc);check(drain().isEmpty(),"occupied planting space skipped");
        SwingUtilities.invokeAndWait(()->panel[0].load(hooks.config));check(panel[0].cells[24].isSelected()&&!panel[0].cells[0].isSelected(),"reopening restores selected cells");
        System.out.println("PASS "+checks+" packet-level pattern checks");
    }
}
