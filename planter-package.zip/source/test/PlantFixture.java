import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import java.util.*;
public final class PlantFixture {
 static final class_310 mc=class_310.INSTANCE;
 static int checks,lastSequence;static boolean limited;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static void cycle() throws Exception {
  long until=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>until)throw new AssertionError("No scheduled client task");Thread.sleep(1);}
 }
 static class_2680 soil(String id){return new class_2680(false,0,new class_2248(id),false);}
 static void farmland(int x,int y,int z){mc.field_1687.blocks.put(new class_2338(x,y,z),soil("farmland"));}
 static class_2338 above(class_2338 p){return new class_2338(p.x(),p.y()+1,p.z());}
 static List<class_2885> drain(){
  List<class_2885> out=new ArrayList<>();
  Set<class_2338> unique=new HashSet<>();
  for(class_2596 packet:mc.field_1761.packets){
   check(packet instanceof class_2885,"only block-use packets, no digging actions");
   class_2885 p=(class_2885)packet;class_2338 pos=p.hit.pos;class_243 eye=mc.field_1724.eyes;
   check(p.hand==class_1268.MAIN_HAND&&p.hit.side==class_2350.UP&&!p.hit.inside,"main hand, top face, outside hit");
   check(p.hit.hit.field_1352==pos.x()+.5&&p.hit.hit.field_1351==pos.y()+.9375&&p.hit.hit.field_1350==pos.z()+.5,"farmland top-center hit position");
   double dx=p.hit.hit.field_1352-eye.field_1352,dy=p.hit.hit.field_1351-eye.field_1351,dz=p.hit.hit.field_1350-eye.field_1350;
   check(dx*dx+dy*dy+dz*dz<=25,"all packet hit positions within five blocks");
   check(p.sequence>lastSequence,"strictly increasing interaction sequence");lastSequence=p.sequence;
   check(unique.add(pos),"no duplicate soil in a batch");out.add(p);
  }
  mc.field_1761.packets.clear();mc.field_1761.sentAt.clear();return out;
 }
 static Set<class_2338> positions(List<class_2885> packets){Set<class_2338> set=new HashSet<>();for(class_2885 p:packets)set.add(p.hit.pos);return set;}
 static void freshWorld() throws Exception {
  GLFW.p=false;mc.field_1687=new class_638();cycle();check(drain().isEmpty(),"world change turns module off");
 }
 static void enable() throws Exception {GLFW.p=true;cycle();GLFW.p=false;}
 public static void main(String[] args) throws Exception {
  limited=args.length>0&&args[0].equals("limited");
  mc.field_1724.eyes=new class_243(.5,.9375,.5);
  Set<class_2338> eligible=new HashSet<>();
  for(int x=-6;x<=6;x++)for(int z=-6;z<=6;z++){
   farmland(x,0,z);
   if(x*x+z*z<=25)eligible.add(new class_2338(x,0,z));
  }
  for(class_2338 p:List.of(new class_2338(0,0,0),new class_2338(1,0,0),new class_2338(-1,0,0))){
   mc.field_1687.blocks.put(p,soil(p.x()==0?"dirt":p.x()==1?"stone":"grass_block"));eligible.remove(p);
  }
  for(class_2338 p:List.of(new class_2338(2,0,0),new class_2338(3,0,0))){
   mc.field_1687.blocks.put(above(p),soil(p.x()==2?"erazion:experience_roots":"water"));eligible.remove(p);
  }
  check(eligible.size()>70,"fixture has more than 70 eligible targets");
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  while(!"true".equals(System.getProperty("planter.agent.installed")))cycle();
  cycle();check(drain().isEmpty(),"starts disabled");
  enable();long firstEnd=System.nanoTime();
  List<Long> sendTimes=mc.field_1761.sentAt;
  check(sendTimes.get(sendTimes.size()-1)-sendTimes.get(0)<100_000_000L,"entire batch sent before the 100ms inter-batch delay");
  List<class_2885> first=drain();Set<class_2338> firstPositions=positions(first);
  check(first.size()==(limited?3:70),"70-target cap sent in one client task despite a 64-seed client stack");
  check(eligible.containsAll(firstPositions),"only empty farmland targeted, excluding dirt, stone, grass, water and planted soil");
  if(!limited)check(first.size()==70&&eligible.size()>70,"hard cap prevents exceeding 70 targets");
  check(firstPositions.stream().anyMatch(p->p.x()<0||p.z()<0),"negative coordinates included");
  check(mc.field_1761.synced==1,"selected slot synchronized once before batch");
  check(mc.field_1724.held.count==64,"no fabricated local seed consumption");
  check(firstPositions.stream().allMatch(p->mc.field_1687.method_8320(above(p)).method_26215()),"no fabricated local crop placement");
  cycle();check(System.nanoTime()-firstEnd>=80_000_000L,"default 100ms delay after batch");
  List<class_2885> second=drain();Set<class_2338> secondPositions=positions(second);
  check(firstPositions.equals(secondPositions),"unacknowledged positions retry at the next 100ms batch without a one-second wait");
  check(second.size()==(limited?3:70),"next batch keeps the configured request cap");
  mc.field_1724.held.count=2;cycle();check(drain().size()==(limited?3:70),"held-count reservations do not introduce extra batch delays");
  freshWorld();mc.field_1724.eyes=new class_243(.5,2.5,.5);for(int x=0;x<5;x++)farmland(x,0,0);
  mc.field_1724.held=new class_1799("erazion:crystal_seeds",64);enable();check(drain().isEmpty(),"other seed types ignored");
  mc.field_1724.held=new class_1799("erazion:experience_seeds",0);cycle();check(drain().isEmpty(),"empty XP seed stack pauses requests");
  mc.field_1724.held.count=2;cycle();List<class_2885> small=drain();check(small.size()==(limited?3:5),"nonempty seed stack permits the full eligible request batch");
  cycle();check(drain().size()==(limited?3:5),"no inventory reservation wait before the next batch");
  for(class_2885 p:small)mc.field_1687.blocks.put(above(p.hit.pos),soil("erazion:experience_roots"));
  mc.field_1724.held.count=0;cycle();check(drain().isEmpty(),"stops when acknowledged planting consumes seeds");
  mc.field_1724.held.count=64;mc.field_1761.plantImmediately=true;cycle();List<class_2885> placed=drain();
  check(placed.size()==(limited?2:0),"acknowledged positions skipped and remaining soil covered after refill");
  check(mc.field_1724.held.count==(limited?62:64),"mock server, not agent, consumes planted seeds");
  cycle();check(drain().isEmpty(),"already planted crops prevent further requests");
  class_2338 replant=small.get(0).hit.pos;mc.field_1687.blocks.remove(above(replant));cycle();
  List<class_2885> replanted=drain();check(replanted.size()==1&&replanted.get(0).hit.pos.equals(replant),"replants farmland after crop removed");
  mc.field_1761.plantImmediately=false;
  freshWorld();farmland(0,0,0);farmland(1,0,0);mc.field_1724.held.count=1;enable();
  check(drain().size()==2,"nonempty one-seed stack does not artificially cap the requested batch");long attempted=System.nanoTime();
  cycle();List<class_2885> retry=drain();
  check(System.nanoTime()-attempted>=80_000_000L,"retry waits only the 100ms batch delay");
  check(retry.size()==2,"both unacknowledged targets retried together");
  freshWorld();mc.field_1724.eyes=new class_243(.5,.9375,.5);mc.field_1724.held.count=64;
  farmland(5,0,0);farmland(-4,0,-3);farmland(0,-5,0);farmland(5,0,1);farmland(6,0,0);
  enable();Set<class_2338> edge=positions(drain());
  check(edge.equals(Set.of(new class_2338(5,0,0),new class_2338(-4,0,-3),new class_2338(0,-5,0))),"exact radius boundary including negative X/Z/Y, excluding diagonal and farther soil");
  mc.field_1755=new Object();cycle();check(drain().isEmpty(),"menu pauses");mc.field_1755=null;
  mc.focused=false;cycle();check(drain().isEmpty(),"lost focus pauses");mc.focused=true;
  Thread.sleep(220);check(mc.queue.size()==1,"single pending task during busy frame");cycle();drain();
  cycle();check(mc.queue.size()==0,"no backlog after busy frame");drain();
  GLFW.p=true;cycle();drain();GLFW.p=false;cycle();check(drain().isEmpty(),"P turns requests off");
  if(limited){
   System.out.println("WAIT_STOP");System.out.flush();
   while(!Boolean.getBoolean("planter.agent.stop"))Thread.sleep(1);
   cycle();check(drain().isEmpty(),"CMD stop prevents new packets");
  }else{
   GLFW.end=true;cycle();check(drain().isEmpty(),"End stops without a packet");
  }
  Thread.sleep(220);check(mc.queue.isEmpty(),"scheduler shuts down after stop");
  System.out.println("PASS "+checks+" 70-request crop planter checks"+(limited?" (budget 3 and CMD stop)":" (default and End)"));System.out.flush();
 }
}
