import net.minecraft.*;
import org.lwjgl.glfw.GLFW;
import java.util.*;
public final class PlantFixture {
 static final class_310 mc=class_310.INSTANCE;static int checks,lastSequence;static boolean limited;
 static void check(boolean value,String message){if(!value)throw new AssertionError(message);checks++;}
 static void cycle() throws Exception {
  long until=System.nanoTime()+2_000_000_000L;
  while(true){Runnable r=mc.queue.poll();if(r!=null){r.run();return;}
   if(System.nanoTime()>until)throw new AssertionError("No scheduled client task");Thread.sleep(1);}
 }
 static class_2680 block(String id){return new class_2680(id.equals("air"),0,new class_2248(id),false);}
 static void put(int x,int y,int z,String id){mc.field_1687.blocks.put(new class_2338(x,y,z),block(id));}
 static class_2338 above(class_2338 p){return new class_2338(p.x(),p.y()+1,p.z());}
 static List<class_2885> drain(){
  List<class_2885> out=new ArrayList<>();Set<class_2338> unique=new HashSet<>();
  for(class_2596 packet:mc.field_1761.packets){
   check(packet instanceof class_2885,"only block-use packets");
   class_2885 p=(class_2885)packet;class_2338 pos=p.hit.pos;class_243 eye=mc.field_1724.eyes;
   check(pos.y()==(int)Math.floor(Math.nextDown(mc.field_1724.feet)),"every support is on the layer immediately below actual feet");
   check(p.hand==class_1268.MAIN_HAND&&p.hit.side==class_2350.UP&&!p.hit.inside,"main-hand top-face interaction");
   double top=mc.field_1687.method_8320(pos).top();
   check(top>0&&p.hit.hit.field_1352==pos.x()+.5&&p.hit.hit.field_1351==pos.y()+top&&p.hit.hit.field_1350==pos.z()+.5,"hit uses actual collision top-center");
   double dx=p.hit.hit.field_1352-eye.field_1352,dy=p.hit.hit.field_1351-eye.field_1351,dz=p.hit.hit.field_1350-eye.field_1350;
   check(dx*dx+dy*dy+dz*dz<=64,"hit point within eight blocks");
   check(p.sequence>lastSequence,"interaction sequences increase");lastSequence=p.sequence;
   check(unique.add(pos),"no duplicates in a batch");out.add(p);
  }
  mc.field_1761.packets.clear();mc.field_1761.sentAt.clear();return out;
 }
 static Set<class_2338> positions(List<class_2885> packets){Set<class_2338> out=new HashSet<>();for(class_2885 p:packets)out.add(p.hit.pos);return out;}
 static void freshWorld() throws Exception {GLFW.p=false;mc.field_1687=new class_638();cycle();check(drain().isEmpty(),"world change disables module");}
 static void enable() throws Exception {GLFW.p=true;cycle();GLFW.p=false;}
 public static void main(String[] args) throws Exception {
  limited=args.length>0;mc.field_1724.feet=1;mc.field_1724.eyes=new class_243(.5,1,.5);
  mc.field_1724.held=new class_1799("minecraft:cobblestone",64);
  Set<class_2338> eligible=new HashSet<>();
  for(int x=-9;x<=9;x++)for(int z=-9;z<=9;z++){
   put(x,0,z,"stone");put(x,-2,z,"dirt");put(x,3,z,"stone");
   if(x*x+z*z<=64)eligible.add(new class_2338(x,0,z));
  }
  put(0,0,0,"dirt");put(1,0,0,"grass_block");put(-1,0,0,"farmland");
  put(2,1,0,"crop");eligible.remove(new class_2338(2,0,0));
  put(3,1,0,"water");eligible.remove(new class_2338(3,0,0));
  for(int z:List.of(2,3,-2)){put(0,0,z,z==2?"air":z==3?"water":"tall_grass");eligible.remove(new class_2338(0,0,z));}
  check(eligible.size()>70,"more than 70 usable support blocks");
  System.out.println("READY "+ProcessHandle.current().pid());System.out.flush();
  while(!"true".equals(System.getProperty("planter.agent.installed")))cycle();
  cycle();check(drain().isEmpty(),"starts off");
  enable();long firstEnd=System.nanoTime();List<Long> times=mc.field_1761.sentAt;
  check(times.get(times.size()-1)-times.get(0)<100_000_000L,"burst has no 100ms per-target wait");
  List<class_2885> first=drain();Set<class_2338> firstPositions=positions(first);
  check(first.size()==(limited?3:70),"single batch capped at 70 or configured lower budget");
  check(eligible.containsAll(firstPositions),"skips occupied spaces, air and non-colliding supports");
  check(firstPositions.contains(new class_2338(0,0,0)),"ordinary dirt accepts a held building block");
  check(firstPositions.stream().anyMatch(p->p.x()<0||p.z()<0),"negative coordinates included");
  check(mc.field_1724.held.count==64,"no local inventory fabrication");
  check(firstPositions.stream().allMatch(p->mc.field_1687.method_8320(above(p)).method_26215()),"no local placement fabrication");
  check(mc.field_1761.synced==1,"syncs selected slot before burst");
  cycle();check(System.nanoTime()-firstEnd>=80_000_000L,"100ms inter-batch delay");
  Set<class_2338> visited=new HashSet<>(firstPositions);
  Set<class_2338> secondPositions=positions(drain());
  check(Collections.disjoint(firstPositions,secondPositions),"second batch continues instead of retrying nearest positions");
  check(secondPositions.size()==(limited?3:70),"continuation keeps request budget");visited.addAll(secondPositions);
  int batches=2;
  while(visited.size()<eligible.size()){
   cycle();Set<class_2338> next=positions(drain());
   check(!next.isEmpty()&&next.size()<=(limited?3:70),"remaining sweep sends a bounded batch");
   check(eligible.containsAll(next)&&Collections.disjoint(visited,next),"no target repeats before the complete area is covered even without server acknowledgements");
   visited.addAll(next);check(++batches<=70,"full sweep completes without starvation");
  }
  check(visited.equals(eligible),"every eligible block in the eight-block area is reached");
  check(visited.contains(new class_2338(8,0,0))&&visited.contains(new class_2338(-8,0,0)),"outer positive and negative radius targets reached despite rejected nearby requests");
  cycle();check(positions(drain()).equals(firstPositions),"only after completing the full sweep does a new batch restart at nearest targets");
  mc.field_1724.held=new class_1799("erazion:experience_seeds",2);cycle();check(drain().size()==(limited?3:70),"seeds also work without item restrictions or stock-count reservations");
  mc.field_1724.held=new class_1799("minecraft:stick",64);cycle();check(!drain().isEmpty(),"arbitrary non-seed item also interacts");
  mc.field_1724.held.count=0;cycle();check(drain().isEmpty(),"empty main hand pauses");
  // Movement inside the same block and temporary pauses keep progress.
  freshWorld();mc.field_1724.held=new class_1799("minecraft:cobblestone",64);
  for(int x=-8;x<=8;x++)for(int z=-8;z<=8;z++)put(x,0,z,"stone");enable();
  Set<class_2338> beforePause=positions(drain());
  mc.field_1755=new Object();cycle();check(drain().isEmpty(),"menu does not advance sweep");mc.field_1755=null;
  mc.field_1724.held.count=0;cycle();check(drain().isEmpty(),"empty hand preserves sweep position");
  mc.field_1724.held.count=64;mc.field_1724.eyes.field_1352=.6;cycle();
  Set<class_2338> continued=positions(drain());
  check(!continued.isEmpty()&&Collections.disjoint(beforePause,continued),"pause, refill and fractional movement continue where the prior batch stopped");
  mc.field_1724.eyes.field_1352=1.5;cycle();Set<class_2338> moved=positions(drain());
  check(moved.contains(new class_2338(1,0,0)),"entering a different player block starts a new nearest-first area");
  freshWorld();mc.field_1724.feet=2;mc.field_1724.eyes=new class_243(.5,3.5,.5);
  for(int x=0;x<5;x++)put(x,1,0,"dirt");put(-1,0,0,"stone");put(-2,2,0,"stone");
  mc.field_1724.held=new class_1799("minecraft:oak_planks",3);mc.field_1761.plantImmediately=true;enable();
  List<class_2885> accepted=drain();check(accepted.size()==3,"mock server consumes held blocks and remaining empty stack stops burst");
  check(mc.field_1724.held.count==0,"server consumes three held building blocks");
  cycle();check(drain().isEmpty(),"empty stack stops further interactions");
  mc.field_1724.held.count=64;cycle();check(drain().size()==2,"refill covers remaining two empty positions");
  cycle();check(drain().isEmpty(),"placed blocks above supports are skipped");
  class_2338 rebuild=accepted.get(0).hit.pos;mc.field_1687.blocks.remove(above(rebuild));cycle();
  List<class_2885> rebuilt=drain();check(rebuilt.size()==1&&rebuilt.get(0).hit.pos.equals(rebuild),"removed top block permits placing again");
  mc.field_1761.plantImmediately=false;
  mc.field_1724.feet=3;mc.field_1724.eyes=new class_243(.5,4.5,.5);cycle();
  List<class_2885> raised=drain();check(raised.size()==(limited?3:6),"moving feet up selects the new support layer only");
  freshWorld();mc.field_1724.feet=.9375;mc.field_1724.eyes=new class_243(.5,2.5,.5);put(0,0,0,"farmland");put(1,-1,0,"stone");enable();
  List<class_2885> farm=drain();check(farm.size()==1&&farm.get(0).hit.hit.field_1351==.9375,"standing on farmland selects its own Y layer and lowered top");
  freshWorld();mc.field_1724.feet=.5;mc.field_1724.eyes=new class_243(.5,2,.5);put(0,0,0,"slab");put(1,-1,0,"stone");enable();
  List<class_2885> slab=drain();check(slab.size()==1&&slab.get(0).hit.hit.field_1351==.5,"standing on a slab targets the actual half-height top");
  freshWorld();mc.field_1724.feet=-.0625;mc.field_1724.eyes=new class_243(.5,1.5,.5);put(0,-1,0,"farmland");put(1,-2,0,"stone");enable();
  List<class_2885> negative=drain();check(negative.size()==1&&negative.get(0).hit.pos.y()==-1,"fractional negative feet select the correct support layer");
  freshWorld();mc.field_1724.feet=0;mc.field_1724.eyes=new class_243(.5,0,.5);
  put(8,-1,0,"stone");put(-8,-1,0,"stone");put(0,-1,6,"stone");
  put(8,-1,1,"stone");put(9,-1,0,"stone");put(0,-2,0,"stone");enable();
  Set<class_2338> farTargets=positions(drain());
  check(farTargets.equals(Set.of(new class_2338(8,-1,0),new class_2338(-8,-1,0),new class_2338(0,-1,6))),"targets exactly eight blocks away in positive and negative coordinates, and six blocks away, excluding outside-radius and wrong-layer blocks");
  check(farTargets.stream().anyMatch(pos->pos.x()*pos.x()+pos.z()*pos.z()>25),"new target range extends beyond the old five-block limit");
  mc.field_1755=new Object();cycle();check(drain().isEmpty(),"menu pauses");mc.field_1755=null;
  mc.focused=false;cycle();check(drain().isEmpty(),"lost focus pauses");mc.focused=true;
  Thread.sleep(220);check(mc.queue.size()==1,"single pending task during busy frame");cycle();drain();
  cycle();check(mc.queue.isEmpty(),"no backlog after busy frame");drain();
  GLFW.p=true;cycle();drain();GLFW.p=false;cycle();check(drain().isEmpty(),"P disables module");
  if(limited){System.out.println("WAIT_STOP");System.out.flush();while(!Boolean.getBoolean("planter.agent.stop"))Thread.sleep(1);cycle();check(drain().isEmpty(),"CMD stop halts requests");}
  else{GLFW.end=true;cycle();check(drain().isEmpty(),"End stops without sending packets");}
  Thread.sleep(220);check(mc.queue.isEmpty(),"scheduler shuts down");
  System.out.println("PASS "+checks+" continuous-sweep placement checks"+(limited?" (budget 3 and CMD stop)":" (70 requests and End)"));System.out.flush();
 }
}
