package org.lwjgl.glfw;
public class GLFW {public static boolean p,end;public static int glfwGetKey(long w,int k){return ((k==80&&p)||(k==269&&end))?1:0;}}
