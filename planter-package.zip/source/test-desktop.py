#!/usr/bin/env python3
"""Requires a desktop DISPLAY and full Java desktop libraries; tests separate processes."""
import os,pathlib,subprocess,threading,queue,time
root=pathlib.Path(__file__).resolve().parent
jar=root/'dist/planter-agent.jar'
java=os.environ.get('PLANTER_DESKTOP_JAVA','java')
cp=str(root/'build/test-classes')+':'+str(jar)
processes=[]
def spawn(args):
 p=subprocess.Popen(args,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 processes.append(p)
 q=queue.Queue()
 def pump():
  for line in p.stdout:
   print(line,end='',flush=True);q.put(line.strip())
  q.put(None)
 threading.Thread(target=pump,daemon=True).start()
 return p,q
def until(q,prefix,timeout=20):
 deadline=time.monotonic()+timeout
 while time.monotonic()<deadline:
  line=q.get(timeout=max(.01,deadline-time.monotonic()))
  if line is None:raise RuntimeError('Process exited before '+prefix)
  if line.startswith(prefix):return line
 raise RuntimeError('Timeout waiting for '+prefix)
def send(p,text):p.stdin.write(text+'\n');p.stdin.flush()
try:
 game,gq=spawn(['java','-Djava.awt.headless=true','-cp',cp,'planter.HeadlessGameFixture'])
 pid=until(gq,'READY ').split()[1]
 gui,uq=spawn([java,'-Djava.awt.headless=false','--add-modules','jdk.attach','-cp',cp,'planter.RemoteWindowFixture',pid,str(jar)])
 until(uq,'APPLIED');send(game,'verify')
 until(gq,'PASS external Apply');send(gui,'reopen')
 until(uq,'REOPENED');send(game,'stop');send(gui,'observe-stop')
 until(gq,'PASS external controller');until(uq,'PASS external GUI')
 for p in [gui,game]:
  p.wait(timeout=10)
  if p.returncode!=0:raise RuntimeError('Fixture failed: '+str(p.returncode))
 print('PASS real desktop controller attached to headless JVM; no launcher setting changes required',flush=True)
finally:
 for p in processes:
  if p.poll() is None:p.kill();p.wait()
