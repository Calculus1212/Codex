#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build/classes dist
java com.sun.tools.javac.Main -source 21 -target 21 --add-modules jdk.attach -d build/classes src/planter/*.java
cat > build/MANIFEST.MF <<'MANIFEST'
Manifest-Version: 1.0
Main-Class: planter.Attach
Agent-Class: planter.Agent
Can-Redefine-Classes: false
Can-Retransform-Classes: false

MANIFEST
java sun.tools.jar.Main --create --file dist/planter-agent.jar --manifest build/MANIFEST.MF -C build/classes .
