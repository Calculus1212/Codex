@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  java --add-modules jdk.attach -jar planter-agent.jar --list
  echo.
  echo Usage: attach.cmd MinecraftPID
  echo Stop:  attach.cmd MinecraftPID stop
  exit /b
)
if "%~2"=="stop" (
  java --add-modules jdk.attach -jar planter-agent.jar "%~1" "%~dp0planter-agent.jar" stop
) else (
  java --add-modules jdk.attach -jar planter-agent.jar "%~1" "%~dp0planter-agent.jar" "radius=5,budget=70,interval=100"
)
