@echo off
setlocal
cd /d "%~dp0"
java -jar erazion-baritone-patcher.jar
if errorlevel 1 (
  echo.
  echo Put the original erazion.jar and baritone-api-fabric-1.15.0.jar beside this script.
  pause
  exit /b 1
)
echo.
pause
