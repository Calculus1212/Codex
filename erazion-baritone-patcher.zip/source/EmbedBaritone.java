import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;

/** Offline archive editor for the exact two uploaded JARs. Does not execute their code. */
public final class EmbedBaritone {
    static final String ERAZION_HASH="bc68ffa29c5e4c098064a1fd0ff339786ff9a351a670cd870c3bc3a85eb8f336";
    static final String BARITONE_HASH="c58ef35a133b6ffce96a74682138ac2ee818cbc063b7c62671db9f9d7d783ebb";
    static final String NESTED="META-INF/jars/baritone-api-fabric-1.15.0.jar";

    public static void main(String[] args) {
        try {
            if(args.length!=0 && args.length!=3)throw new IOException("Usage: java -jar erazion-baritone-patcher.jar [erazion.jar baritone-api-fabric-1.15.0.jar output.jar]");
            Path source=Path.of(args.length==0?"erazion.jar":args[0]).toAbsolutePath();
            Path baritone=Path.of(args.length==0?"baritone-api-fabric-1.15.0.jar":args[1]).toAbsolutePath();
            Path output=Path.of(args.length==0?"erazion-with-baritone.jar":args[2]).toAbsolutePath();
            checkHash(source,ERAZION_HASH,"Erazion");checkHash(baritone,BARITONE_HASH,"Baritone");
            if(Files.exists(output))throw new IOException("Output already exists. Rename or move it first: "+output);
            patch(source,baritone,output);
            System.out.println("Created: "+output);
            System.out.println("SHA-256: "+hash(output));
            System.out.println("Original files preserved. Existing Fabric modules preserved.");
            System.out.println("Close Minecraft, back up its installed erazion.jar, and replace it with this output renamed erazion.jar.");
        } catch(Exception failure) {
            System.err.println("Patch failed: "+failure.getMessage());System.exit(1);
        }
    }
    static void checkHash(Path p,String expected,String label)throws Exception {
        if(!Files.isRegularFile(p))throw new IOException("Missing "+label+" JAR: "+p);
        if(!hash(p).equals(expected))throw new IOException(label+" does not match the uploaded version. Use the original, unedited JAR supplied for this patch.");
    }
    static String hash(Path p)throws Exception {
        MessageDigest digest=MessageDigest.getInstance("SHA-256");
        try(InputStream in=Files.newInputStream(p)){byte[] buffer=new byte[65536];int n;while((n=in.read(buffer))!=-1)digest.update(buffer,0,n);}
        return HexFormat.of().formatHex(digest.digest());
    }
    static String registerNested(String original)throws IOException {
        int key=original.indexOf("\"jars\"");int start=original.indexOf('[',key);
        if(key<0||start<0)throw new IOException("No nested-mod list in Erazion metadata");
        int depth=0;boolean quoted=false,escaped=false;
        for(int i=start;i<original.length();i++){
            char c=original.charAt(i);
            if(quoted){if(escaped)escaped=false;else if(c=='\\')escaped=true;else if(c=='\"')quoted=false;continue;}
            if(c=='\"'){quoted=true;continue;}
            if(c=='[')depth++;
            if(c==']'&&--depth==0){
                String preceding=original.substring(start+1,i);
                String addition=(preceding.isBlank()?"":",")+"\n    {\n      \"file\": \""+NESTED+"\"\n    }\n  ";
                return original.substring(0,i).stripTrailing()+addition+original.substring(i);
            }
        }
        throw new IOException("Invalid nested-mod list");
    }
    static void patch(Path source,Path baritone,Path output)throws Exception {
        byte[] nested=Files.readAllBytes(baritone);
        // CREATE_NEW avoids clobbering any original or existing output, including aliases.
        boolean created=false,complete=false;
        try(ZipFile input=new ZipFile(source.toFile())){
            ZipEntry metadata=input.getEntry("fabric.mod.json");
            if(metadata==null||input.getEntry(NESTED)!=null)throw new IOException("Unexpected Erazion archive structure");
            byte[] updated;
            try(InputStream in=input.getInputStream(metadata)){
                updated=registerNested(new String(in.readAllBytes(),StandardCharsets.UTF_8)).getBytes(StandardCharsets.UTF_8);
            }
            OutputStream file=Files.newOutputStream(output,StandardOpenOption.CREATE_NEW,StandardOpenOption.WRITE);created=true;
            try(ZipOutputStream result=new ZipOutputStream(new BufferedOutputStream(file))){
                Set<String> seen=new HashSet<>();
                for(Enumeration<? extends ZipEntry> entries=input.entries();entries.hasMoreElements();){
                    ZipEntry old=entries.nextElement();
                    if(!seen.add(old.getName()))throw new IOException("Duplicate ZIP entry: "+old.getName());
                    ZipEntry entry=new ZipEntry(old.getName());entry.setTime(old.getTime());
                    if(old.getComment()!=null)entry.setComment(old.getComment());
                    if(old.getExtra()!=null)entry.setExtra(old.getExtra());
                    boolean changed=old.getName().equals("fabric.mod.json");
                    entry.setMethod(changed?ZipEntry.DEFLATED:old.getMethod());
                    if(entry.getMethod()==ZipEntry.STORED){entry.setSize(old.getSize());entry.setCrc(old.getCrc());}
                    result.putNextEntry(entry);
                    if(changed)result.write(updated);
                    else if(!old.isDirectory())try(InputStream in=input.getInputStream(old)){in.transferTo(result);}
                    result.closeEntry();
                }
                ZipEntry entry=new ZipEntry(NESTED);entry.setTime(metadata.getTime());
                result.putNextEntry(entry);result.write(nested);result.closeEntry();
            }
            complete=true;
        } finally {if(created&&!complete)Files.deleteIfExists(output);}
    }
}
